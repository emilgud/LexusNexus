﻿using System;
using NFUM.FMS.LexisNexis.Service.API.RESTClasses;
using NFUM.FMS.LexisNexis.Service.Interfaces;

namespace NFUM.FMS.LexisNexis.Client.ConsoleApp
{
    class Program
    {
        #region Locals
        static ApiRequest<NfumRequestIdentityVerification> _apiRequest;
        #endregion

        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("Starting up LexisNexis API...");
                _apiRequest = new ApiRequest<NfumRequestIdentityVerification>();
                Console.WriteLine("Completed configuration");
                // Register for message-cast:
                _apiRequest.RegisterForMessageCast(new ApiRequest<NfumRequestIdentityVerification>.CastMessageHandler(OnMessageCast));
                // Register for exception-cast event:
                _apiRequest.ThrownException += ApiRequest_ThrownException;
                Console.WriteLine("Registered to receive messages");
                Console.WriteLine("Starting request to from LexisNexis....");
                // Go and do it!:
                GetData();
                Console.WriteLine("Processing LexisNexis request completed");
                if (_apiRequest.IsSuccessFul) Console.WriteLine("Process was successful");
                else
                {
                    Console.WriteLine($"Process failed: {_apiRequest?.ErrorMessage}");
                    throw new Exception($"Process failed: {_apiRequest?.ErrorMessage}");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"LexisNexis API exception: {ex}");
                //throw new Exception($"LexisNexis API refresh exception: {ex.ToString()}");
            }
        }

        #region Methods
        /// <summary>
        /// Get- and process providers
        /// </summary>
        /// <returns></returns>
        static void GetData()
        {
            if (_apiRequest.Login()) 
            {
                // Create NFUM lookup structure with minimum set of criteria:
                NfumRequestIdentityVerification nfumRequestIdentityVerification = new NfumRequestIdentityVerification(
                    reference: "Hub_Test132",
                    surName: "STONE",
                    dateOfBirth: "1976-04-11",
                    address1: "200",
                    postcode: "BS7 8EU");

                //Provide some optional details:
                nfumRequestIdentityVerification.Forename = "ROY";

                NFUM.FMS.LexisNexis.Service.API.RESTClasses.Service[] services = new NFUM.FMS.LexisNexis.Service.API.RESTClasses.Service[]{ 
                    new NFUM.FMS.LexisNexis.Service.API.RESTClasses.Service { Name = "Address" }
                };
                nfumRequestIdentityVerification.Product = new Product { Name = LexisNexisHubRequest.IDU_PRODUCT_NAME, Services = services };

                string response = _apiRequest?.PostRequest(nfumRequestIdentityVerification);
            }            
            else throw new Exception("Could not log in");
        }
        #endregion Methods

        #region Event handling
        /// <summary>
        /// New fragment of text has been cast
        /// </summary>
        /// <param name="message"></param>
        /// <returns></returns> 
        static string OnMessageCast(string message)
        {
            Console.Clear();
            Console.WriteLine(message);
            return message;
        }

        /// <summary>
        /// Exception in API refresh was raised
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        static void ApiRequest_ThrownException(object sender, ApiRequest<NfumRequestIdentityVerification>.ApiRequestArgs e)
        {
            OnMessageCast(e.ToString());
            Console.WriteLine($"ERROR: {e}");
            throw new Exception(e.ToString());
        }
        #endregion Event handling
    }
}
