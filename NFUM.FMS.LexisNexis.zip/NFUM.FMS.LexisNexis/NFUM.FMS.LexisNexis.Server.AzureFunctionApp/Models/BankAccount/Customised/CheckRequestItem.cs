/*
 * Parties API
 *
 * Customised additions to VerificationRequestItem
 * *
 */

using System;
using System.Linq;
using System.IO;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using Newtonsoft.Json;
using NFUM.FMS.LexisNexis.Service.API.RESTClasses;
using System.Text.RegularExpressions;

namespace IO.Swagger.Models
{ 
    public partial class CheckRequestItem : IEquatable<CheckRequestItem>, ICommonRequestMethods
    {
        /// <summary>
        /// At the moment (5 November 2020), the Solution Design doesn't fully match the Swagger model structure (i.e. this class)
        /// This is a (temporary?) method to map a CheckRequestItem-object (based on NFUM Swagger) with an NfumRequestBankValidation-object (based on SD-document)
        /// By using a partial class, this code will be retained if the code would need to be regenerated from the Swagger Hub
        /// </summary>
        /// <returns></returns>
        public NfumRequest ToNfumRequest()
        {
            try
            {
                // Remove non-numeric characters from account- and sort-number:
                string sortCodeFiltered, accountNumberFiltered;
                Regex numbersOnly = new Regex("[^0-9]");
                sortCodeFiltered = numbersOnly.Replace(this.SortCode, "");
                accountNumberFiltered = numbersOnly.Replace(this.AccountNumber, "");

                var nfumRequest = new NfumRequestBankValidation(reference: this.Reference, sortCode: sortCodeFiltered, accountNumber: accountNumberFiltered);
                return nfumRequest;

            }
            catch
            {
                return null;
            }
        }

    }
}
