﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using NFUM.FMS.LexisNexis.Service.API.RESTClasses;

namespace IO.Swagger.Models
{
    /// <summary>
    /// Defines common methods that need implementing on the request-models defined on SwaggerHub
    /// This for example can deal with (temporary?) discrepencies between the original solution desgn documents and the Swagger model 
    /// so we can amend any mappings without having to make any additional changes in the underlying code
    /// Note - these request-methods are best stored as separate partial class-files, allowing to fully re-import and replace the current 
    /// models from SwaggerHub if this were necessary
    /// </summary>
    public interface ICommonRequestMethods
    {
        public NfumRequest ToNfumRequest();
    }
}
