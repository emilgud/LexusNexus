﻿using System;
using System.Collections.Generic;
using System.Text;
using NFUM.FMS.LexisNexis.Service.API.RESTClasses;

namespace IO.Swagger.Models
{
    public partial class SanctionsCheckRequestItem : IEquatable<SanctionsCheckRequestItem>, ICommonRequestMethods
    {
        /// <summary>
        /// A (temporary?) method to map a SanctionsCheckRequestItem-object (based on NFUM Swagger) with an NfumRequestIdentityVerification-object (based on SD-document)
        /// At the moment (5 November 2020), the Solution Design doesn't fully match the Swagger model structure (i.e. this class)
        /// This is a (temporary?) method to map a SanctionsCheckRequestItem-object (based on NFUM Swagger) with an NfumRequestSanction-object (based on SD-document)
        /// By using a partial class, this code will be retained if the code would need to be regenerated from the Swagger Hub
        /// </summary>
        /// <returns></returns>
        public NfumRequest ToNfumRequest()
        {
            try
            {
                var nfumRequest = new NfumRequestSanction(reference: this.Reference, address1: this.Address1, postcode: this.Postcode);
                if (this.Gender == null || this.Gender == GenderEnum.NONEEnum) nfumRequest.Gender = null; else nfumRequest.Gender = GetGenderString(this.Gender);
                if (!string.IsNullOrWhiteSpace(this.BusinessName)) nfumRequest.BusinessName = this.BusinessName; else nfumRequest.BusinessName = null;
                if (!string.IsNullOrWhiteSpace(this.Surname)) nfumRequest.Surname = this.Surname; else nfumRequest.Surname = null;
                if (string.IsNullOrWhiteSpace(this.DateOfBirth))
                    nfumRequest.DateOfBirth = null;
                else
                    nfumRequest.DateOfBirth = this.DateOfBirth;
                if (!string.IsNullOrWhiteSpace(this.Address2)) nfumRequest.Address2 = this.Address2; else nfumRequest.Address2 = null;
                if (!string.IsNullOrWhiteSpace(this.Address3)) nfumRequest.Address3 = this.Address3; else nfumRequest.Address3 = null;
                if (!string.IsNullOrWhiteSpace(this.Address4)) nfumRequest.Address4 = this.Address4; else nfumRequest.Address4 = null;
                if (!string.IsNullOrWhiteSpace(this.Address5)) nfumRequest.Town = this.Address5; else nfumRequest.Town = null;
                if (!string.IsNullOrWhiteSpace(this.Forename)) nfumRequest.Forename = this.Forename; else nfumRequest.Forename = null;
                if (!string.IsNullOrWhiteSpace(this.Middlename)) nfumRequest.Middlename = this.Middlename; else nfumRequest.Middlename = null;
                //if (!string.IsNullOrWhiteSpace(this.Address5)) nfumRequest.County = this.Address5; // No explicit reference to county or postcode

                return nfumRequest;
            }
            catch
            {
                return null;
            }

        }
        /// <summary>
        /// Translate the GenderEnum-type into a single character string, compatible with the Lexis Nexis gender-attribute
        /// </summary>
        /// <param name="gender"></param>
        /// <returns></returns>
        private string GetGenderString(GenderEnum? gender) {
            try
            {
                if (gender == GenderEnum.FEMALEEnum) return "F";
                else if (gender == GenderEnum.MALEEnum) return "M";
                else return "U";
            }
            catch { return "U"; }
        }
    }
}
