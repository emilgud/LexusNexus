using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
//using System.Text.Json;
//using System.Text.Json.Serialization;
using NFUM.FMS.LexisNexis.Client;
using NFUM.FMS.LexisNexis.Service.API.RESTClasses;
using IO.Swagger.Models;
using NFUM.FMS.LexisNexis.Server.AzureFunctionApp.Utilities;
using System.Diagnostics;
using System.Collections.Generic;

namespace NFUM.FMS.LexisNexis.Server.AzureFunctionApp
{
    /// <summary>
    /// Archive Function - not fully implemented 
    /// </summary>
    public static class CustomerScreeningArchiveApi
    {
        const string VersionNumber = "2.0.6";

        static ConfigSettings _configSettings = null;
        static ILogger _logger;

        /// <summary>
        /// archives a verification result into a report document
        /// </summary>
        /// <param name="req"></param>
        /// <param name="logger"></param>
        /// <param name="context"></param>
        /// <returns></returns>
        [FunctionName("IdentitiesArchiveVerificationPost")]
        public static async Task<IActionResult> Run(
            //[FromBody] ArchiveRequestItem body,
            [HttpTrigger(AuthorizationLevel.Function, "post", Route = NFUM.FMS.LexisNexis.Service.API.ApiConstants.NFUM_API_URL_BASE_IDENTITIES + "/" + VersionNumber + "/archive-verification")] HttpRequest req,
            ILogger logger,
            ExecutionContext context
        )
        {
            _logger = logger;
            // Get the comnnfiguration details:
            _configSettings = ApiConfigUtilities.GetConfig(context, _logger);
            if (_configSettings == null)
            {
                _logger?.LogError($"Error in {context.FunctionName}: could not retrieve the configuration");
                return new NotFoundResult();
            }

            // Get the archive request from the request-body
            ArchiveRequestItem archiveRequest;
            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();

            // Retrieve the archive-request information from the body:
            try
            {
                archiveRequest = JsonConvert.DeserializeObject<ArchiveRequestItem>(requestBody);
            }
            catch (Exception ex)
            {
                _logger?.LogError($"Error in {context.FunctionName}: {ex}");
#if DEBUG
                return new BadRequestObjectResult(ex);
#else
                return new BadRequestResult();
#endif
            }

            if (archiveRequest == null ) 
            {
                _logger?.LogError($"Could not retrieve the archive-request in {context.FunctionName}");
                return new BadRequestResult();
            }

            // TO-DO - implement the logic to retrieve the archived request


            throw new NotImplementedException();
        }
    }
}
