using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using NFUM.FMS.LexisNexis.Service.API.RESTClasses;
using IO.Swagger.Models;


namespace NFUM.FMS.LexisNexis.Server.AzureFunctionApp
{
    public static class BankAccountVerificationApi
    {
        const string VersionNumber = "1.0.4";

        /// <summary>
        /// Verify bank details and ownership for a personal account only
        /// </summary>
        /// <remarks>Verifies bank account details for a personal account and also verifies ownership and address details are recent - NOT TO BE USED FOR BUSINESS ACCOUNTS</remarks>
        /// <param name="req"></param>
        /// <param name="logger"></param>
        /// <param name="context"></param>
        /// <returns></returns>
        [FunctionName("VerifyPost")]
        public static async Task<IActionResult> Run(
            //[FromBody] VerifyRequestItem bankInformation,
            [HttpTrigger(AuthorizationLevel.Function, "post", Route = NFUM.FMS.LexisNexis.Service.API.ApiConstants.NFUM_API_URL_BASE_BANK_ACCOUNTS + "/" + VersionNumber + "/verify/{productGroup?}/{serviceGroup?}")] HttpRequest req,
            ILogger logger,
            ExecutionContext context,
            string productGroup,
            string serviceGroup
        )
        {
            return await HubRequestProcessor.ProcessRequest<VerifyRequestItem, NfumRequestBankVerification, VerifyResponseItem, NfumResponseBankVerification>(req, logger, context, productGroup, serviceGroup);
        }
    }
}
