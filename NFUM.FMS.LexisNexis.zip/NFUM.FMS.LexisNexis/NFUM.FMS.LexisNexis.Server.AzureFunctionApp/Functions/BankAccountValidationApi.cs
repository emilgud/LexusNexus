using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using NFUM.FMS.LexisNexis.Service.API.RESTClasses;
using IO.Swagger.Models;


namespace NFUM.FMS.LexisNexis.Server.AzureFunctionApp
{
    public static class BankAccountValidationApi
    {
        const string VersionNumber = "1.0.4";

        /// <summary>
        /// Validates bank account details (sort code and account number) for both personal and business accounts
        /// </summary>
        /// <remarks>Validates bank account details (sort code and account number) for both personal and business accounts</remarks>
        /// <param name="req"></param>
        /// <param name="logger"></param>
        /// <param name="context"></param>
        /// <returns></returns>
        [FunctionName("CheckPost")]
        public static async Task<IActionResult> Run(
            //[FromBody] CheckRequestItem bankInformation,
            [HttpTrigger(AuthorizationLevel.Function, "post", Route = NFUM.FMS.LexisNexis.Service.API.ApiConstants.NFUM_API_URL_BASE_BANK_ACCOUNTS + "/" + VersionNumber + "/check/{productGroup?}/{serviceGroup?}")] HttpRequest req,
            ILogger logger,
            ExecutionContext context,
            string productGroup,
            string serviceGroup
        )
        {
            return await HubRequestProcessor.ProcessRequest<CheckRequestItem, NfumRequestBankValidation, CheckResponseItem, NfumResponseBankValidation>(req, logger, context, productGroup, serviceGroup);
        }
    }
}
