using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using NFUM.FMS.LexisNexis.Client;
using NFUM.FMS.LexisNexis.Service.API.RESTClasses;
using IO.Swagger.Models;
using NFUM.FMS.LexisNexis.Server.AzureFunctionApp.Utilities;
using System.Diagnostics;
using System.Collections.Generic;

namespace NFUM.FMS.LexisNexis.Server.AzureFunctionApp
{
    /// <summary>
    /// Processor of API requests shared by all Lexis Nexis Hub requests
    /// </summary>
    public static class HubRequestProcessor
    {
        static ConfigSettings _configSettings = null;
        static ILogger _logger;

        /// <summary>
        /// Generic processing of Lexis Nexis API Function request-paths
        /// </summary>
        /// <param name="req"></param>
        /// <param name="logger"></param>
        /// <param name="context"></param>
        /// <param name="productGroup">Filter for product-group. Optional, unless service-group is specified</param>
        /// <param name="serviceGroup">Optional filter for service-group within the supplied product-group</param>
        /// <returns></returns>
        public static async Task<IActionResult> ProcessRequest<TSwaggerModelRequest, TNfumRequest, TSwaggerModelResponse, TNfumResponse>(HttpRequest req, ILogger logger, ExecutionContext context, string productGroup = "", string serviceGroup = "")
            where TSwaggerModelRequest : ICommonRequestMethods
            where TNfumRequest : NfumRequest
            where TNfumResponse : NfumResponse
        {
            _logger = logger;
            // Get the comnnfiguration details:
            _configSettings = ApiConfigUtilities.GetConfig(context, _logger);
            if (_configSettings == null)
            {
                _logger?.LogError($"Error in {context.FunctionName}: could not retrieve the configuration");
                return new NotFoundResult();
            }

            // Parse tokens from header:
             string fmsSubscriptionKey = req.Headers[Service.API.ApiConstants.FMS_SUBSCRIPTION_KEY];
            fmsSubscriptionKey = fmsSubscriptionKey ?? Service.API.ApiConstants.FMS_SUBSCRIPTION_KEY_NONE;

            // Bearer-tokens: 
            // Both Lexis Nexis itself and its "fronting" NFUM's hosted version of the LN API have their own bearer tokens, 
            // expected in the "Authorization" header. 
            // APIM support policies where you can authenticate the fronting API in APIM with the NFUM AAD bearer-token supplied in the standard "Authorization" header,
            // while the LN token, initially provided in an aliased header, can then take the place of the standard "Authorization" header in the subsequent call
            // into the public LN API.
            // However, when testing locally we don not use APIM - in that case, we provide the LN bearer token and just use a dummy Authorization token-header for
            // a made-up NFUM AAD token that won't get used for testing.
            // Whether we are testing or running live is assumed by running in DEBUG mode (testing) or not (live deployed in Azure)
#if DEBUG
            bool useAzureApiManager = (_configSettings.DebugAgainstAPIM == "1") ;
#else
            bool useAzureApiManager = (_configSettings.ReleaseOutsideAPIM != "1");
#endif            
            string aadBearerToken = null;

            if (useAzureApiManager) 
                aadBearerToken = req.Headers[Service.API.ApiConstants.AAD_BEARER_TOKEN]; // Live scenario using APIM: get NFUM AAD token from the deault authorisation header
            else 
                aadBearerToken = req.Headers[Service.API.ApiConstants.AAD_BEARER_TOKEN_DUMMY];  // Test-scenario - pass in a dummy token from a bespoke header (optionally), for example from Postman

            aadBearerToken = aadBearerToken ?? Service.API.ApiConstants.AAD_BEARER_TOKEN_NONE;
            string fmsRequestNumber = req.Headers[Service.API.ApiConstants.FMS_REQUEST_NUMBER];
            string apimTrackingId = req.Headers[Service.API.ApiConstants.APIM_TRACKING_ID];
            string headersLogString = $"FMS request {fmsRequestNumber}, APIM tracking-ID {apimTrackingId}: ";

            // Add custom headers to logging:
            Activity.Current?.AddTag(Service.API.ApiConstants.APIM_TRACKING_ID, apimTrackingId);
            Activity.Current?.AddTag(Service.API.ApiConstants.FMS_REQUEST_NUMBER, fmsRequestNumber);

            // Parse subject information for the individual from the body:
            TSwaggerModelRequest subjectInformation;
            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();

            // Retrieve the subject information from the body:
            try
            {
                subjectInformation = JsonConvert.DeserializeObject<TSwaggerModelRequest>(requestBody);
            }
            catch (Exception ex)
            {
                _logger?.LogError(ex, $"{headersLogString}Exception in retrieving valid subject-information from request'{requestBody}' in function '{context.FunctionName}': {ex}");
                req.HttpContext.Response.Headers.Add(Service.API.ApiConstants.APIM_TRACKING_ID, apimTrackingId);
                req.HttpContext.Response.Headers.Add(Service.API.ApiConstants.FMS_REQUEST_NUMBER, fmsRequestNumber);
                req.HttpContext.Response.Headers.Add("ContentType", "application/json");
                return new BadRequestResult();
            }
            // Set up the API request:
            ApiRequest<TNfumRequest> ApiRequest = new ApiRequest<TNfumRequest>(_configSettings?.LexisNexisEndpointBase, _configSettings.KeyVault);
            // Register for message-cast:
            ApiRequest.RegisterForMessageCast(new ApiRequest<TNfumRequest>.CastMessageHandler(OnMessageCast));
            // Register for exception-cast event:
            ApiRequest.ThrownException += ApiRequest_ThrownException;
            if (ApiRequest.Login())
            {
                try
                {
                    TNfumRequest NfumRequest = (TNfumRequest)subjectInformation?.ToNfumRequest();
                    if (NfumRequest == null)
                    {
                        string toNfumRequestError = $"{headersLogString}Function '{context.FunctionName}': Failed to convert the Swagger-request";
                        _logger?.LogError(toNfumRequestError);
                        throw new Exception(toNfumRequestError);
                    }

                    NfumRequest.Products = ApiConfigUtilities.GetProductsFromConfig(_configSettings, NfumRequest.ProductCategory, productGroup, serviceGroup, NfumRequest.ProductName);
                    NfumRequest.ProductOptions = ApiConfigUtilities.GetProductOptionsFromConfig(_configSettings, NfumRequest.ProductName, NfumRequest.ProductCategory);
                    // Build the collection of custom-headers to be included in the http-request:
                    if (_configSettings.UseCustomerHeaders == "1")
                    {
                        ApiRequest.CustomRequestHeaders = new Dictionary<string, string>() {
                            { Service.API.ApiConstants.FMS_SUBSCRIPTION_KEY, fmsSubscriptionKey },
                            { Service.API.ApiConstants.FMS_REQUEST_NUMBER, fmsRequestNumber },
                            { Service.API.ApiConstants.APIM_TRACKING_ID, apimTrackingId }
                        };
                        if (useAzureApiManager)
                        {
                            // Live-scenario: Provide the LN token in an aliased request header while the NFUM AAD token is passed in the default authorisation header as a bearer;
                            // APIM will then authentcate the NFUM AAD token and subsequently swap the header with the LN token when calling into the LN API: 
                            ApiRequest.CustomRequestHeaders.Add(Service.API.ApiConstants.AAD_BEARER_TOKEN, aadBearerToken);
                            ApiRequest.CustomRequestHeaders.Add(Service.API.ApiConstants.LN_APIM_BEARER_TOKEN, ApiRequest.ApiLoginClient.BearerToken);  
                        }
                        else 
                        {
                            // Typical test-scenario: Direct call into LN, so pass the LN token directly in the default authorisation header, while passing
                            // a dummy token to represent the NFUM AAD token:
                            ApiRequest.CustomRequestHeaders.Add(Service.API.ApiConstants.AAD_BEARER_TOKEN_DUMMY, aadBearerToken);                       
                        }
                    }

                    // Raw JSON response directly from the LN API:
                    var response = ApiRequest?.PostRequest(NfumRequest);
                    _logger?.LogDebug($"{headersLogString}Request '{subjectInformation?.ToString()}' for user '{ApiRequest?.ApiLoginClient?.UserLogin}' on endpoint {ApiRequest?.ApiQueryClient?.EndPointUrl} in function '{context.FunctionName}' - response: {response}");
                    if (!ApiRequest.IsSuccessFul) throw new Exception(ApiRequest?.ErrorMessage);
                }
                catch (Exception ex)
                {
                    _logger?.LogError(ex, $"{headersLogString}Exception in the request '{subjectInformation?.ToString()}' for user '{ApiRequest?.ApiLoginClient?.UserLogin}' on endpoint {ApiRequest?.ApiQueryClient?.EndPointUrl} in function '{context.FunctionName}': {ApiRequest?.ErrorMessage}");
                    req.HttpContext.Response.Headers.Add(Service.API.ApiConstants.APIM_TRACKING_ID, apimTrackingId);
                    req.HttpContext.Response.Headers.Add(Service.API.ApiConstants.FMS_REQUEST_NUMBER, fmsRequestNumber);

#if DEBUG
                    return new BadRequestObjectResult(ex);
#else
                    return new BadRequestResult();
#endif
                }

                // Transform the raw response-object into a list of strongly typed responses:
                List<TNfumResponse> NfumResponseList = (List<TNfumResponse>)ApiRequest?.NfumResponses;
                if (NfumResponseList?.Count > 0)
                {
                    if (ApiRequest.Errors > 0)
                    {
                        _logger?.LogError($"{headersLogString}{ApiRequest.Errors} error(s) for user '{ApiRequest?.ApiLoginClient?.UserLogin}' on endpoint {ApiRequest?.ApiQueryClient?.EndPointUrl} in function '{context.FunctionName}': {ApiRequest?.ErrorMessage}");
                        req.HttpContext.Response.Headers.Add(Service.API.ApiConstants.APIM_TRACKING_ID, apimTrackingId);
                        req.HttpContext.Response.Headers.Add(Service.API.ApiConstants.FMS_REQUEST_NUMBER, fmsRequestNumber);
#if DEBUG
                        return new NotFoundObjectResult(ApiRequest?.ErrorMessage);  // 404
#else
                        return new NotFoundResult();  // 404
#endif
                    }
                    else
                    {
                        try
                        {
                            TSwaggerModelResponse responseItem = NfumResponseList[0].ToJson(suppressError: true) != null
                            ? JsonConvert.DeserializeObject<TSwaggerModelResponse>(NfumResponseList[0].ToJson(suppressError: true))
                            : default(TSwaggerModelResponse);

                            _logger?.LogInformation($"{headersLogString}Successful request for user '{ApiRequest?.ApiLoginClient?.UserLogin}' on endpoint {ApiRequest?.ApiQueryClient?.EndPointUrl} in function '{context.FunctionName}'");
                            _logger?.LogDebug(headersLogString + responseItem?.ToString());
                            req.HttpContext.Response.Headers.Add(Service.API.ApiConstants.APIM_TRACKING_ID, apimTrackingId);
                            req.HttpContext.Response.Headers.Add(Service.API.ApiConstants.FMS_REQUEST_NUMBER, fmsRequestNumber);
                            return new OkObjectResult(responseItem);
                        }
                        catch (Exception ex)
                        {
                            _logger?.LogError(ex, $"{headersLogString}Exception transforming the raw response '{NfumResponseList[0]?.ToString()}' for '{subjectInformation?.ToString()}' for user '{ApiRequest?.ApiLoginClient?.UserLogin}' on endpoint {ApiRequest?.ApiQueryClient?.EndPointUrl}': {ApiRequest?.ErrorMessage}");
                            req.HttpContext.Response.Headers.Add(Service.API.ApiConstants.APIM_TRACKING_ID, apimTrackingId);
                            req.HttpContext.Response.Headers.Add(Service.API.ApiConstants.FMS_REQUEST_NUMBER, fmsRequestNumber);
#if DEBUG
                            return new BadRequestObjectResult($"{headersLogString}Exception transforming the raw response '{NfumResponseList[0]?.ToString()}' for '{subjectInformation?.ToString()}' for user '{ApiRequest?.ApiLoginClient?.UserLogin}' on endpoint {ApiRequest?.ApiQueryClient?.EndPointUrl}': {ApiRequest?.ErrorMessage}: {ex}"); // 400
#else
                            return new BadRequestResult(); // 400
#endif
                        }
                    }
                }
                else
                {
                    _logger?.LogInformation($"{headersLogString}No results found for user '{ApiRequest?.ApiLoginClient?.UserLogin}' on endpoint {ApiRequest?.ApiQueryClient?.EndPointUrl} in function '{context.FunctionName}': {ApiRequest?.ErrorMessage}");
                    req.HttpContext.Response.Headers.Add(Service.API.ApiConstants.APIM_TRACKING_ID, apimTrackingId);
                    req.HttpContext.Response.Headers.Add(Service.API.ApiConstants.FMS_REQUEST_NUMBER, fmsRequestNumber);
#if DEBUG
                    return new NotFoundObjectResult(ApiRequest?.ErrorMessage);  // 404
#else
                    return new NotFoundResult();  // 404
#endif
                }
            }
            else
            {
                _logger?.LogWarning($"{headersLogString}Login problem for user '{ApiRequest?.ApiLoginClient?.UserLogin}' on endpoint {ApiRequest?.ApiLoginClient?.EndPointUrl} in function '{context.FunctionName}': {ApiRequest?.ErrorMessage}");
                req.HttpContext.Response.Headers.Add(Service.API.ApiConstants.APIM_TRACKING_ID, apimTrackingId);
                req.HttpContext.Response.Headers.Add(Service.API.ApiConstants.FMS_REQUEST_NUMBER, fmsRequestNumber);
                return new UnauthorizedResult(); // 401
            }
        }
#region Event handling

        /// <summary>
        /// New fragment of text has been cast
        /// </summary>
        /// <param name="message"></param>
        /// <returns></returns> 
        static string OnMessageCast(string message) 
        {
            _logger?.LogInformation(message);
            return message;
        }

        /// <summary>
        /// Exception in API was raised
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        static void ApiRequest_ThrownException<T>(object sender, ApiRequest<T>.ApiRequestArgs e) where T : NfumRequest
        {
            _logger?.LogError(e.Ex, e.ToString());
        }
#endregion
    }
}
