using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
//using System.Text.Json;
//using System.Text.Json.Serialization;
using NFUM.FMS.LexisNexis.Client;
using NFUM.FMS.LexisNexis.Service.API.RESTClasses;
using IO.Swagger.Models;
using NFUM.FMS.LexisNexis.Server.AzureFunctionApp.Utilities;
using System.Diagnostics;
using System.Collections.Generic;

namespace NFUM.FMS.LexisNexis.Server.AzureFunctionApp
{
    public static class CustomerScreeningApi
    {
        const string VersionNumber = "2.0.6";

        /// <summary>
        /// verifies the identity of an individual
        /// Generates a request to verify the identity of an individual based on the information supplied and provide results and a location to a supporting report in response.
        /// </summary>
        /// <param name="req"></param>
        /// <param name="logger"></param>
        /// <param name="context"></param>
        /// <param name="productGroup">Filter for product-group. Optional, unless service-group is specified</param>
        /// <param name="serviceGroup">Optional filter for service-group within the supplied product-group</param>
        /// <returns></returns>
        [FunctionName("IdentitiesVerifyPost")]
        public static async Task<IActionResult> Run(
            //[FromBody] VerificationRequestItem subjectInformation,
            [HttpTrigger(AuthorizationLevel.Function, "post", Route = NFUM.FMS.LexisNexis.Service.API.ApiConstants.NFUM_API_URL_BASE_IDENTITIES + "/" + VersionNumber + "/verify/{productGroup?}/{serviceGroup?}")] HttpRequest req,
            //[HttpTrigger(AuthorizationLevel.Function, "post", Route = NFUM.FMS.LexisNexis.Service.API.ApiConstants.NFUM_API_URL_BASE + "/{verify:regex(^verify$)}/{productGroup?}/{serviceGroup?}")] HttpRequest req,
            //[HttpTrigger(AuthorizationLevel.Function, "post", Route = NFUM.FMS.LexisNexis.Service.API.ApiConstants.NFUM_API_URL_BASE + "/verify")] HttpRequest req,
            ILogger logger,
            ExecutionContext context,
            string productGroup,
            string serviceGroup
        )
        {
            return await HubRequestProcessor.ProcessRequest<VerificationRequestItem, NfumRequestIdentityVerification, IDVerificationResponseItem, NfumResponseIdentityVerification>(req, logger, context, productGroup, serviceGroup);
        }
    }
}
