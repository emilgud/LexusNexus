using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
//using System.Text.Json;
//using System.Text.Json.Serialization;
using NFUM.FMS.LexisNexis.Client;
using NFUM.FMS.LexisNexis.Service.API.RESTClasses;
using IO.Swagger.Models;
using NFUM.FMS.LexisNexis.Server.AzureFunctionApp.Utilities;
using System.Diagnostics;
using System.Collections.Generic;

namespace NFUM.FMS.LexisNexis.Server.AzureFunctionApp
{
    public static class SanctionsApi
    {
        const string VersionNumber = "2.0.6";

        /// <summary>
        /// Checks to determine if the subject matches to any sanctions
        /// </summary>
        /// <param name="req"></param>
        /// <param name="logger"></param>
        /// <param name="context"></param>
        /// <param name="productGroup">Filter for product-group. Optional, unless service-group is specified</param>
        /// <param name="serviceGroup">Optional filter for service-group within the supplied product-group</param>
        /// <returns></returns>
        [FunctionName("SanctionsCheckPost")]
        public static async Task<IActionResult> Run(
            //[FromBody] SanctionsCheckRequestItem subjectInformation,
            [HttpTrigger(AuthorizationLevel.Function, "post", Route = NFUM.FMS.LexisNexis.Service.API.ApiConstants.NFUM_API_URL_BASE_SANCTIONS + "/" + VersionNumber + "/check/{productGroup?}/{serviceGroup?}")] HttpRequest req,
            ILogger logger,
            ExecutionContext context,
            string productGroup,
            string serviceGroup
        )
        {
            return await HubRequestProcessor.ProcessRequest<SanctionsCheckRequestItem, NfumRequestSanction, SanctionsCheckResponseItem, NfumResponseSanction>(req, logger, context, productGroup, serviceGroup);
        }
    }
}
