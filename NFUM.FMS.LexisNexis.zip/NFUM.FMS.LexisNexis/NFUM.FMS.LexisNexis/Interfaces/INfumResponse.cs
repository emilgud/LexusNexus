﻿using System;
using System.Collections.Generic;
using System.Text;
using NFUM.FMS.LexisNexis.Service.API.RESTClasses;

namespace NFUM.FMS.LexisNexis.Service.Interfaces
{
    public interface INfumResponse
    {
        #region Properties
        [Newtonsoft.Json.JsonIgnore]
        public string System { get; set; } // Exclude "System" propery because it is not part of th specification
        public string Error { get; set; } // "Error" is not part of the specification but is still returned if indeed an error has been returned by the API - this may need changing!

        /// <summary>
        /// Mandatory  : consumer defined identifier stored against the search for future retrieval from IDU if required
        /// </summary>
        [Newtonsoft.Json.JsonIgnore]        
        public string[] References { get; set; } 
        /// <summary>
        /// Reference in the NFUM interface is defined as one value while LN has an array of references.
        /// </summary>
        public string Reference { get; }

        #endregion

        #region Methods
        public string ToJson(bool suppressError = false);
        #endregion
    }
}
