﻿using System;
using System.Collections.Generic;
using System.Text;
using NFUM.FMS.LexisNexis.Service.API.RESTClasses;

namespace NFUM.FMS.LexisNexis.Service.Interfaces
{
    public interface INfumRequest
    {
        [Newtonsoft.Json.JsonIgnore]
        public string ProductName { get; }

        [Newtonsoft.Json.JsonIgnore]
        public string ProductCategory { get; }

        /// <summary>
        /// Single product
        /// </summary>
        [Newtonsoft.Json.JsonIgnore]
        public Product Product { get; set; }

        /// <summary>
        /// Products
        /// </summary>
        [Newtonsoft.Json.JsonIgnore]
        public Product[] Products { get; set; }

        /// <summary>
        /// Product-options
        /// </summary>
        [Newtonsoft.Json.JsonIgnore]
        public ProductOption[] ProductOptions { get; set; }

        [Newtonsoft.Json.JsonIgnore]
        public string[] References { get; set; } // - Mandatory  : consumer defined identifier stored against the search for future retrieval from IDU if required

        /// <summary>
        /// Reference in the NFUM interface is defined as one value while LN has an array of references. For now, just return the first memeber of this array
        /// </summary>
        public string Reference { get; }
        public string ResultID { get; set; } // 	- Optional : result-id (i.e. "ID" in LN) from previous request
        public string IDKey { get; set; } // 	- Optional : ID-key (i.e. "Ikey" in LN) from previous request
        public string Surname { get; set; } // 	- Mandatory
        public string Forename { get; set; } 
        public string Middlename { get; set; }   
        public string DateOfBirth { get; set; } // 	- Mandatory
        public string Address1 { get; set; } // 	- Mandatory
        public string Address2 { get; set; }// 	- Optional
        public string Address3 { get; set; } // - Optional
        public string Address4 { get; set; } // - Optional
        public string Town { get; set; } // 	- Optional
        public string County { get; set; } // 	- Optional
        public string Postcode { get; set; } // 	- Optional - but will need to be made mandatory because it's manadatory in LN!
        public string SortCode { get; set; }
        public string AccountNumber { get; set; }

        #region Methods
        public StringBuilder Validate();
        public LexisNexisHubRequest ToLexisNexisHubRequest();
        //public Object ParseResponse<T>(List<string> references, List<T> nfumResponses, Newtonsoft.Json.Linq.JObject jObject, List<string> errorList); // where T : NfumResponse;
        public List<string> ParseResponse(List<string> references, Newtonsoft.Json.Linq.JObject jObject, ref Object nfumResponses);
        #endregion
    }
}
