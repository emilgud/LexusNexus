﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using NFUM.Azure.KeyVault.ValueProvider;

namespace NFUM.FMS.LexisNexis.Service.API
{
    public class ApiLoginClient
    {
        public readonly string EndPointUrl;
        public readonly string UserLogin;
        public readonly string Password;

        public string ErrorMessage => _errorMessage;
        public int Errors => _errors = 0;
        public bool IsSuccessFul => _errors == 0;

        public string LoginTransactionId { get; set; }
        public string BearerToken { get; set; }
        private string _keyVault = ApiConstants.KEY_VAULT_NAME;

        #region Locals
        private string _errorMessage = "";
        private int _errors = 0;
        private StringBuilder errorMessageBuilder = new StringBuilder();
        #endregion
        public ApiLoginClient() : this(ApiConstants.LEXIS_NEXIS_API_ENDPOINT_DEFAULT) { }
        public ApiLoginClient(string endPointUrlBase) : this(endPointUrlBase, ApiConstants.KEY_VAULT_NAME) { }

        public ApiLoginClient(string endPointUrlBase, string keyVault) 
        {
            _keyVault = keyVault;
            EndPointUrl = endPointUrlBase + "login";
            try
            {
                _errors = 0;
                // In debug-mode, use hard-coded credentials, otherwise access the key-vault:
#if DEBUG
                //UserLogin = "RVanelst01";
                //Password = "547BvynIY8";
                UserLogin = "vanero01";
                Password = "Hv4JyiI939";
#else
                Task<string> GetLogin = GetKeyVaultValueAsync(ApiConstants.LEXIS_NEXIS_API_KEYVAULT_KEY_LOGIN);
                GetLogin.Wait();
                UserLogin = GetLogin.Result;
                Task<string> GetPassword = GetKeyVaultValueAsync(ApiConstants.LEXIS_NEXIS_API_KEYVAULT_KEY_PASSWORD);
                GetPassword.Wait();
                Password = GetPassword.Result;
#endif
            }
            catch (Exception ex)
            {
                _errors++;
                errorMessageBuilder.Append($"Exception when getting values from key-values: {ex.ToString()}");
            }
            _errorMessage = errorMessageBuilder.ToString();
        }

        private async System.Threading.Tasks.Task<string> GetKeyVaultValueAsync(string key)
        {
            int retries = ApiConstants.KEYVAULT_MAX_RETRIES;
            try
            {
                KeyVaultMember keyVaultMember = new KeyVaultMember(key, _keyVault);
                Task<string> getValue = keyVaultMember.GetValue(retries);
                getValue.Wait();
                //string value = await keyVaultMember.GetValue(retries);
                string value = getValue.Result;

                if (keyVaultMember.IsSuccessFul) return value;
                else
                {
                    _errors ++;
                    errorMessageBuilder.Append($"Something went wrong: '{keyVaultMember.ErrorMessage}', returning {((value == null) ? "null" : value)}");
                    return string.Empty;
                }
            }
            catch (Exception ex)
            {
                _errors ++;
                errorMessageBuilder.Append(ex.ToString());
                return string.Empty;
            }
        }
    }
}
