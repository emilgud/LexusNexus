﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NFUM.FMS.LexisNexis.Service.API
{
    public class ApiQueryClient
    {

        public readonly string EndPointUrl;
        public ApiQueryClient() : this(ApiConstants.LEXIS_NEXIS_API_ENDPOINT_DEFAULT) { }
        public ApiQueryClient(string endPointUrlBase)
        {
            EndPointUrl = endPointUrlBase + "query";
        }
    }
    }
