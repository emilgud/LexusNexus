﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NFUM.FMS.LexisNexis.Service.API
{
    public class ApiConstants
    {
        public const int DEFAULT_NUMBER_PER_PAGE = 250;
        public const int REQUEST_MAX_RETRIES = 3;
        public const int KEYVAULT_MAX_RETRIES = 2;
        public const string LEXIS_NEXIS_API_ENDPOINT_DEFAULT = "https://sandbox.hub.risk.lexisnexis.co.uk/";
        //public const string KEY_VAULT_NAME = "https://nfum318lndev01ukskv01.vault.azure.net/";
        public const string KEY_VAULT_NAME = "https://nfum318lndev01ukskv01.vault.azure.net/secrets/LNDev01/965cc7a633be4374bf33a6149dc2ba9b";
        public const string LEXIS_NEXIS_API_KEYVAULT_KEY_LOGIN = "sandbox-hub-login";
        public const string LEXIS_NEXIS_API_KEYVAULT_KEY_PASSWORD = "sandbox-hub-password";
        public const string API_APPLICATION_NAME = "LEXIS_NEXIS API";
        public const string NFUM_API_URL_BASE_IDENTITIES = "rest/parties/identities"; // NFU-Mutual/parties/2.0.0/identities
        public const string NFUM_API_URL_BASE_SANCTIONS = "rest/parties/sanctions"; // NFU-Mutual/parties/2.0.0/sanctions
        public const string NFUM_API_URL_BASE_BANK_ACCOUNTS = "rest/bank-accounts"; // NFU-Mutual/parties/1.0.0/bank-accounts
        public const string FMS_SUBSCRIPTION_KEY = "Ocp-Apim-Subscription-Key";
        public const string FMS_SUBSCRIPTION_KEY_NONE = "(no FMS key)";
        public const string AAD_BEARER_TOKEN = "Authorization"; // Standard Bearer-Token request header for the NFUM-AAD token when deployed in APIM on Azure
        public const string AAD_BEARER_TOKEN_DUMMY = "Authorization-NFUM"; //  Dummy Bearer-Token request header alias for the NFUM-AAD token when runnin glocally in debug-mode
        public const string AAD_BEARER_TOKEN_NONE =  "(no bearer token)";
        public const string LN_APIM_BEARER_TOKEN = "X-Authorization-LN";  // Aliased Bearer-token request-header to contain the LN API token when calling into APIM, alongside the NFUM AAD token in the standard "Authorization" header
        public const string FMS_REQUEST_NUMBER = "X-Request-ID";
        public const string APIM_TRACKING_ID = "X-Correlation-ID";
    }
}
