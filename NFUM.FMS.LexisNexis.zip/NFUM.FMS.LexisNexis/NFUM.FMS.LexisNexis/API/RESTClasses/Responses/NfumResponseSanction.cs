﻿using NFUM.API.Request.JsonConvertors;
using System;
using System.Collections.Generic;
using System.Text;
using NFUM.FMS.LexisNexis.Service.Interfaces;

namespace NFUM.FMS.LexisNexis.Service.API.RESTClasses
{
    /// <summary>
    /// Sanctions result response
    /// </summary>
    public class NfumResponseSanction : NfumResponse
    {
        public string SanctionsResult { get; set; }

        /// <summary>
        /// Constructor - in case we will never return references in Sanction responses
        /// </summary>
        public NfumResponseSanction()
        {
        }
        /// <summary>
        /// Constructor - pass in the minimum set of mandatory fields - multiple references
        /// </summary>
        /// <param name="references"></param>
        public NfumResponseSanction(string[] references)
        {
            References = references;
        }
        /// <summary>
        /// Constructor - pass in the minimum set of mandatory fields - using a single reference
        /// </summary>
        /// <param name="reference"></param>
        public NfumResponseSanction(string reference)
        {
            References = new string[] { reference };
        }

        /// <summary>
        /// Reference in the NFUM interface is defined as one value while LN has an array of references. For now, just return the first member of this array
        /// If references are not used in Sanction responses then return null
        /// Note - if we want to start returning "reference" in the associated NFUM Swagger model type "SanctionsCheckResponseItem" then remove the "JsonIgnore attribute on its "Reference" property
        /// </summary>
        public override string Reference
        {
            get
            {
                if (References == null || References?.Length == 0) return null;
                else return References[0];
            }
        }


    }
}
