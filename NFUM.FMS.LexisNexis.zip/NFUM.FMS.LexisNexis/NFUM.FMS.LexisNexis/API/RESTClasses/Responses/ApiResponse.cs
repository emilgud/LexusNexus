﻿using System;
using System.Collections.Generic;
using System.Text;
using NFUM.FMS.LexisNexis.Service.Interfaces;

//namespace NFUM.FMS.LexisNexis.Service.API.RESTClasses
//{
//    /// <summary>
//    /// Generic container for API responses
//    /// </summary>
//    /// <typeparam name="T"></typeparam>
//    public class ApiResponse<T>
//    {
//        public List<T> Responses = new List<T>();
//    }
//}
