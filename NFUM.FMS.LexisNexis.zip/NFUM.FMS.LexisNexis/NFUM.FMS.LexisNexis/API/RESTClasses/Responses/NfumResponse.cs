﻿using NFUM.API.Request.JsonConvertors;
using System;
using System.Collections.Generic;
using System.Text;
using NFUM.FMS.LexisNexis.Service.Interfaces;

namespace NFUM.FMS.LexisNexis.Service.API.RESTClasses
{
    /// <summary>
    /// Respnse base-class  - NFUM models
    /// </summary>
    public abstract class NfumResponse : INfumResponse
    {
        /// <summary>
        /// Exclude "System" propery because it is not part of the specification
        /// </summary>
        [Newtonsoft.Json.JsonIgnore]
        public string System { get; set; }

        /// <summary>
        /// "Error" is not part of the specification but is still returned if indeed an error has been returned by the API - this may need changing!
        /// </summary>
        public string Error { get; set; }

        /// <summary>
        /// Mandatory  : consumer defined identifier stored against the search for future retrieval from IDU if required
        /// </summary>
        [Newtonsoft.Json.JsonIgnore]
        public string[] References { get; set; }

        /// <summary>
        /// Reference in the NFUM interface is defined as one value while LN has an array of references. For now, just return the first memeber of this array
        /// </summary>
        public abstract string Reference { get; }
        //public virtual string Reference
        //{
        //    get
        //    {
        //        if (References == null || References?.Length == 0) return string.Empty;
        //        else return References[0];
        //    }
        //}

        /// <summary>
        /// Constructor - no arguments
        /// </summary>
        /// <param name="references"></param>
        public NfumResponse() { }

        /// <summary>
        /// Constructor - pass in the minimum set of mandatory fields - multiple references
        /// </summary>
        /// <param name="references"></param>
        public NfumResponse(string[] references)
        {
            References = references;
        }

        /// <summary>
        /// Constructor - pass in the minimum set of mandatory fields - using a single reference
        /// </summary>
        /// <param name="reference"></param>
        public NfumResponse(string reference)
        {
            References = new string[] { reference };
        }

        /// <summary>
        /// Render this as JSON (all lower-case)
        /// </summary>
        /// <returns></returns>
        public string ToJson(bool suppressError=false)
        {
            // Make sure to exclude Error-property from setting it to Null if it has no content
            if (suppressError || string.IsNullOrWhiteSpace(Error)) Error = null;

            return new JsonLowerCaseSerialiser().SerialiseObject(this);
        }
    }
}
