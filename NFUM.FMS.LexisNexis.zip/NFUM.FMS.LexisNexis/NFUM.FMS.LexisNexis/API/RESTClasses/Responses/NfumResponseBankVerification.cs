﻿using NFUM.API.Request.JsonConvertors;
using System;
using System.Collections.Generic;
using System.Text;
using NFUM.FMS.LexisNexis.Service.Interfaces;

namespace NFUM.FMS.LexisNexis.Service.API.RESTClasses
{
    /// <summary>
    /// Request-class as passed in through NFUM
    /// </summary>
    public class NfumResponseBankVerification : NfumResponse
    {
        /// <summary>
        /// Reference in the NFUM interface is defined as one value while LN has an array of references. For now, just return the first memeber of this array
        /// </summary>
        public override string Reference
        {
            get
            {
                if (References == null || References?.Length == 0) return string.Empty;
                else return References[0];
            }
        }
        public string IdentityResult { get; set; } // 	- Mandatory
        public string ResultID { get; set; } // 	- Mandatory
        public string IDKey { get; set; } // 	- Mandatory

        /// <summary>
        /// Constructor - pass in the minimum set of mandatory fields - multiple references
        /// </summary>
        /// <param name="references"></param>
        public NfumResponseBankVerification(string[] references)
        {
            References = references;
        }
        /// <summary>
        /// Constructor - pass in the minimum set of mandatory fields - using a single reference
        /// </summary>
        /// <param name="reference"></param>
        public NfumResponseBankVerification(string reference)
        {
            References = new string[] { reference };
        }

        public string SortCode { get; set; }
        public string AccountNumber { get; set; }
        public string AccountName { get; set; }
        public string AccountAddress { get; set; }
        public string AccountStatus { get; set; }
    }
}
