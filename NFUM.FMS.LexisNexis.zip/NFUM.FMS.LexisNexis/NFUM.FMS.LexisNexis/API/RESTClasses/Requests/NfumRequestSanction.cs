﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Globalization;
using Newtonsoft.Json.Linq;

namespace NFUM.FMS.LexisNexis.Service.API.RESTClasses
{
    /// <summary>
    /// Request-class for Sanctions passed in through NFUM
    /// </summary>
    public class NfumRequestSanction : NfumRequest
    {
        //public const string HUB_RESULT_PASS = "PASS";
        //public const string HUB_RESULT_FAIL = "FAIL";
        public const string NFUM_RESULT_HIT = "HIT";
        public const string NFUM_RESULT_NOHIT = "NO HIT";
        public const string NFUM_RESULT_NOT_REQUESTED = "NA";

        private const string EMPTY_REFERENCE = "no-reference";
        private string[] _references = null;

        public override string ProductName { get { return LexisNexisHubRequest.BRIDGER_PRODUCT_NAME; } }
        public override string ProductCategory { get { return LexisNexisHubRequest.BRIDGER_SANCTION_CATEGORY; } }

        /// <summary>
        /// Reference in the NFUM interface is defined as one value while LN has an array of references. For now, just return the first memeber of this array
        /// Note that reference is optional in Sanction API (as off Nov 2010)
        /// </summary>
        public override string Reference
        {
            get
            {
                if (References == null || References?.Length == 0)
                    return null;
                else if (string.IsNullOrWhiteSpace(References[0]))
                    return null;
                else return References[0];
            }
        }
        
        /// <summary>
        /// Optional  : consumer defined identifier stored against the search for future retrieval from Bridger if required
        /// </summary>
        [Newtonsoft.Json.JsonIgnore]
        public override string[] References { 
            get
            {
                if (_references == null || _references?.Length == 0)
                    return null;
                else if (string.IsNullOrWhiteSpace(_references[0]))
                    return null;
                else 
                    return _references;
            }
            set
            {
                _references = value;
            }
        }

        /// <summary>
        /// Constructor - pass in the minimum set of mandatory fields - multiple references
        /// </summary>
        /// <param name="references"></param>
        /// <param name="surName"></param>
        /// <param name="dateOfBirth"></param>
        /// <param name="address1"></param>
        /// <param name="postcode"></param>
        public NfumRequestSanction(string[] references, string address1, string postcode)
        {
            References = references;
            Address1 = address1;
            Postcode = postcode;
        }

        /// <summary>
        /// Constructor - pass in the minimum set of mandatory fields - using a single reference
        /// </summary>
        /// <param name="reference"></param>
        /// <param name="surName"></param>
        /// <param name="dateOfBirth"></param>
        /// <param name="address1"></param>
        /// <param name="postcode"></param>
        public NfumRequestSanction(string reference, string address1, string postcode)
        {
            // Make sure reference has some content because LN requires it
            // NOTE - we may need to make this manadatory anyway!
            //if (string.IsNullOrWhiteSpace(reference)) reference = EMPTY_REFERENCE;
            if (string.IsNullOrWhiteSpace(reference)) reference = null;
            References = new string[] { reference };
            Address1 = address1;
            Postcode = postcode;
        }

        /// <summary>
        /// Make sure all minimum requirements have been meet
        /// </summary>
        /// <returns></returns>
        public override StringBuilder Validate()
        {
            StringBuilder errors = new StringBuilder();
            try
            {
                //if (References == null || References?.Length == 0 || string.IsNullOrEmpty(References?[0])) errors.AppendLine("No reference(s) supplied");
                if (string.IsNullOrEmpty(Address1)) errors.AppendLine("No address-line 1 supplied");
                if (string.IsNullOrEmpty(Postcode)) errors.AppendLine("No postcode supplied");
                if (!string.IsNullOrEmpty(DateOfBirth))
                {
                    // Validate date-format YYYY-MM-DD
                    try { DateTime dateOfBirth = DateTime.ParseExact(DateOfBirth, "yyyy-MM-dd", CultureInfo.InvariantCulture); } catch { errors.AppendLine($"{DateOfBirth} is not in the format yyyy-MM-DD"); }
                }
            }
            catch (Exception ex)
            {
                errors.AppendLine($"Validation error: {ex.ToString()}");
            }
            return errors;
        }

        /// <summary>
        /// Parse the Sanction response
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="references">LN references</param>
        /// <param name="nfumResponses">List of responses to be populated</param>
        /// <param name="jObject">JSON response object</param>
        /// <returns>A list of error-messages if something had gone wrong</returns>
        public override List<string> ParseResponse(List<string> references, Newtonsoft.Json.Linq.JObject jObject, ref object nfumResponses)
        {
            List<string> errorList = new List<string>();
            // Get references:
            IEnumerable<JToken> tokenReferences = jObject.SelectTokens("references");
            foreach (JToken items in tokenReferences)
            {
                foreach (var item in items)
                {
                    references.Add(item.ToString());
                }
            }
            // Get results from all the systems:
            IEnumerable<JToken> outputResults = jObject.SelectTokens("outputresults");
            List<NfumResponseSanction> nfumResponsesSanction = new List<NfumResponseSanction>();

            bool hitsFound = false;          
            foreach (JToken items in outputResults)
            {

                foreach (var item in items)
                {
                    NfumResponseSanction nfumResponseSanction = new NfumResponseSanction(references.ToArray());
                    // Create NFUM response for each system
                    string responseThisSystem = (string)item.SelectToken("system");
                    nfumResponseSanction.System = responseThisSystem;
                    var errors = (string)item.SelectToken("systemresponse.summary.errors.error.details");
                    // Were any errors returned from the API?
                    if (!string.IsNullOrEmpty(errors))
                    {
                        nfumResponseSanction.Error = errors;
                        errorList.Add(errors);
                    }

                    // TO DO - TEST!  :


                    var sanctionSearchResults = item.SelectTokens("systemresponse.sanction.resulttext");
                    if (sanctionSearchResults == null) nfumResponseSanction.SanctionsResult = NFUM_RESULT_NOT_REQUESTED;
                    else
                    {
                        foreach (var sanctionSearchResult in sanctionSearchResults)
                        {
                            hitsFound = true;
                            break; // Sanction found - no more need to check further
                        }

                        // Apply transformations:
                        // -: Transform LN results into: "HIT" or  "NO HIT":
                        if (hitsFound) nfumResponseSanction.SanctionsResult = NFUM_RESULT_HIT;
                        else nfumResponseSanction.SanctionsResult = NFUM_RESULT_NOHIT;
                    }
                    nfumResponsesSanction.Add(nfumResponseSanction);
                }
            }
            nfumResponses = nfumResponsesSanction;
            return errorList;
        }
    }
}

