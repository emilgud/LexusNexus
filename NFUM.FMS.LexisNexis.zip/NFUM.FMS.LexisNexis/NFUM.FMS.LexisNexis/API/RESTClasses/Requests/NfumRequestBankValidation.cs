﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Globalization;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using NFUM.FMS.LexisNexis.Service.Interfaces;

namespace NFUM.FMS.LexisNexis.Service.API.RESTClasses
{
    /// <summary>
    /// Request-class for Identity Verficationas passed in through NFUM
    /// </summary>
    public class NfumRequestBankValidation : NfumRequest
    {
        public const string HUB_RESULT_PASS = "PASS";
        public const string HUB_RESULT_REFER = "REFER";
        public const string HUB_RESULT_FAIL = "FAIL";
        public const string NFUM_RESULT_PASS = "PASS";
        public const string NFUM_RESULT_REFER = "CHECK";
        public const string NFUM_RESULT_FAIL = "FAIL";

        public override string ProductName { get { return LexisNexisHubRequest.IDU_PRODUCT_NAME; } }
        public override string ProductCategory { get { return LexisNexisHubRequest.IDU_BANKVALIDATION_CATEGORY; } }

        /// <summary>
        /// Constructor - pass in the minimum set of mandatory fields - multiple references
        /// </summary>
        /// <param name="references"></param>
        /// <param name="sortCode"></param>
        /// <param name="accountNumber"></param>
        public NfumRequestBankValidation(string[] references, string sortCode, string accountNumber)
        {
            References = references;
            SortCode = sortCode;
            AccountNumber = accountNumber;
        }

        /// <summary>
        /// Constructor - pass in the minimum set of mandatory fields - using a single reference
        /// </summary>
        /// <param name="reference"></param>
        /// <param name="sortCode"></param>
        /// <param name="accountNumber"></param>
        public NfumRequestBankValidation(string reference, string sortCode, string accountNumber)
        {
            References = new string[] { reference };
            SortCode = sortCode;
            AccountNumber = accountNumber;
        }

        /// <summary>
        /// Make sure all minimum requirements have been meet
        /// </summary>
        /// <returns></returns>
        public override StringBuilder Validate()
        {
            const int SORTCODE_LENGTH = 6;
            StringBuilder errors = new StringBuilder();
            try
            {
                if (References == null || References?.Length == 0 || string.IsNullOrEmpty(References?[0])) errors.AppendLine("No reference(s) supplied");
                if (string.IsNullOrEmpty(SortCode)) errors.AppendLine("No sort-code supplied");
                else if (SortCode.Length != SORTCODE_LENGTH) errors.AppendLine($"Sort-code length is {SortCode.Length}, expected {SORTCODE_LENGTH}");
                if (string.IsNullOrEmpty(AccountNumber)) errors.AppendLine("No account-number supplied");

            }
            catch (Exception ex)
            {
                errors.AppendLine($"Validation error: {ex.ToString()}");
            }
            return errors;
        }

        /// <summary>
        /// Map the NFUM request to a valid Lexis Nexis hub request object ()
        /// </summary>
        /// <returns></returns>
        public override LexisNexisHubRequest ToLexisNexisHubRequest()
        {
            string[] references = this.References;

            // Documents:
            Document[] documents = null;
            // Bank account document:
            documents = new Document[] { new Document
                {
                    Type = "Bank",
                    Details = new DocumentDetail[] {
                        new DocumentDetail { Key = "AccountNumber", Value = this.AccountNumber},
                        new DocumentDetail { Key = "SortCode", Value = this.SortCode }
                    }
                }
            };

            // Finally - the Subject to verify:
            Subject subject = new Subject();
            subject.Type = LexisNexisHubRequest.SUBJECT_TYPE_DEFAULT;
            subject.PersonalDetail = null;
            subject.Addresses = null;
            subject.Documents = documents;

            // Retrieve any configure product-options that need sending across:
            GetProductOptions(this.Products);

            // Product with Services:
            return new LexisNexisHubRequest { References = references, Subject = subject, Products = this.Products };
        }



        /// <summary>
        /// Parse the Identify Verification response
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="references">LN references</param>
        /// <param name="nfumResponses">List of responses to be populated</param>
        /// <param name="jObject">JSON response object</param>
        /// <returns>A list of error-messages if something had gone wrong</returns>
        public override List<string> ParseResponse(List<string> references, Newtonsoft.Json.Linq.JObject jObject, ref object nfumResponses)
        {
            List<string> errorList = new List<string>();
            // Get references:
            IEnumerable<JToken> tokenReferences = jObject.SelectTokens("references");
            foreach (JToken items in tokenReferences)
            {
                foreach (var item in items)
                {
                    references.Add(item.ToString());
                }
            }
            // Get results from all the systems:
            IEnumerable<JToken> outputResults = jObject.SelectTokens("outputresults");
            List<NfumResponseBankValidation> nfumResponsesBankValidation = new List<NfumResponseBankValidation>();

            foreach (JToken items in outputResults)
            {

                foreach (var item in items)
                {
                    NfumResponseBankValidation nfumResponseBankValidation = new NfumResponseBankValidation(references.ToArray());
                    // Create NFUM response for each system
                    string responseThisSystem = (string)item.SelectToken("system");
                    nfumResponseBankValidation.System = responseThisSystem;
                    nfumResponseBankValidation.ResultID = (string)item.SelectToken("systemresponse.summary.id");
                    nfumResponseBankValidation.IdentityResult = (string)item.SelectToken("systemresponse.summary.resulttext");
                    nfumResponseBankValidation.IDKey = (string)item.SelectToken("systemresponse.summary.ikey");

                    nfumResponseBankValidation.BankName = (string)item.SelectToken("systemresponse.bankaccountvalidation.bankname");
                    nfumResponseBankValidation.BranchDetails = (string)item.SelectToken("systemresponse.bankaccountvalidation.branchdetails");
                    nfumResponseBankValidation.Valid = (((string)item.SelectToken("systemresponse.bankaccountvalidation.bankaccountvalid")).ToLower() == "true");
                    nfumResponseBankValidation.BACSPayments = (((string)item.SelectToken("systemresponse.bankaccountvalidation.bacspayments")).ToLower()== "true");
                    nfumResponseBankValidation.CHAPSPayments = (((string)item.SelectToken("systemresponse.bankaccountvalidation.chapspayments")).ToLower() == "true");
                    nfumResponseBankValidation.FasterPayments = (((string)item.SelectToken("systemresponse.bankaccountvalidation.fasterpayments")).ToLower() == "true");
                    nfumResponseBankValidation.DirectDebit = (((string)item.SelectToken("systemresponse.bankaccountvalidation.directdebit")).ToLower() == "true");

                    var errors = (string)item.SelectToken("systemresponse.summary.errors.error.details");
                    // Were any errors returned from the API?
                    if (!string.IsNullOrEmpty(errors))
                    {
                        nfumResponseBankValidation.Error = errors;
                        errorList.Add(errors);
                    }
                    nfumResponsesBankValidation.Add(nfumResponseBankValidation);
                }
            }
            nfumResponses = nfumResponsesBankValidation;
            return errorList;
        }
    }
}
