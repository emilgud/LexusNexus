﻿using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using NFUM.FMS.LexisNexis.Service.Interfaces;

namespace NFUM.FMS.LexisNexis.Service.API.RESTClasses
{

    public class LexisNexisHubRequest
    {
        public const string SUBJECT_TYPE_PERSON = "Person";
        public const string SUBJECT_TYPE_BUSINESS = "Company";
        public const string SUBJECT_TYPE_DEFAULT = SUBJECT_TYPE_PERSON;
        public const string IDU_PRODUCT_NAME = "IDU";
        public const string IDU_IDENTITY_CATEGORY = "Identity";
        public const string IDU_BANKVALIDATION_CATEGORY = "BankAccountValidation";
        public const string IDU_BANKVERIFICATION_CATEGORY = "BankAccountVerification";
        public const string IDU_SERVICE_ADDRESS = "Address";
        public const string IDU_SERVICE_SMARTLINK = "Smartlink";
        public const string IDU_SERVICE_CREDITACTIVE = "CreditActive";
        public const string IDU_SERVICE_DEATHSCREEN = "DeathScreen";
        public const string IDU_SERVICE_DOB  = "DateOfBirth";
        public const string IDU_SERVICE_SANCTION = "Sanction";
        public const string IDU_SERVICE_CCJ = "CCJ";
        public const string IDU_SERVICE_INSOLVENCY = "Insolvency";

        public const string BRIDGER_PRODUCT_NAME = "Bridger";
        public const string BRIDGER_SANCTION_CATEGORY = "Sanction";

        public const string RISKVIEW_PRODUCT_NAME = "RiskView";
        public const string RISKVIEW_CATEGORY = "";

        public const string DEFAULT_IDU_SERVICE_NAME = IDU_SERVICE_ADDRESS;
        public const string NAME_KEY_TYPE_FORENAME = "Forename";
        public const string NAME_KEY_TYPE_SURNAME = "Surname";
        public const string NAME_KEY_TYPE_MIDDLENAME = "Middlename";
        public const string NAME_KEY_TYPE_BUSINESSNAME = "Current";

        [Optional]
        [JsonProperty]
        //[JsonProperty( NullValueHandling = NullValueHandling.Ignore)]
        public string[] References { get; set; } = null;

        [Optional]
        [JsonProperty]
        public string ID { get; set; } = null;// 	- Optional : result-id (i.e. "ResultID" in NFUM) from previous request
        [Optional]
        [JsonProperty]
        public string Ikey { get; set; } = null; // 	- Optional : ID-key (i.e. "IDKey" in NFUM) from previous request


        [Mandatory]
        public Subject Subject { get; set; }

        [Mandatory]
        public Product[] Products { get; set; }

    }

    // It looks like References is just an array of strings?:
    //public class Reference
    //{
    //    [Mandatory]
    //    public string Value { get; set; }
    //    [Optional]
    //    public uint? Order { get; set; }
    //}

    public class Subject
    {
        [Mandatory]
        public string Type { get; set; } = LexisNexisHubRequest.SUBJECT_TYPE_DEFAULT;
        [Mandatory]
        public PersonalDetails PersonalDetail { get; set; }
        [Mandatory]
        public Address[] Addresses { get; set; }
        [Optional]
        public Document[] Documents { get; set; }
        [Optional]
        public CompanyDetails CompanyDetail { get; set; } = null;
    }

    /// <summary>
    /// Subject Personal details
    /// </summary>
    public class PersonalDetails
    {
        [Optional]
        public String Gender = null; // M,F,U
        [Mandatory]
        public Names Names { get; set; }           
        [Optional]
        public String DOB { get; set; } // YYYY-MM-DD
    }

    /// <summary>
    /// Optional details for "Company" type searches
    /// </summary>
    public class CompanyDetails
    {
        [Optional]
        public String RegistrationNumber = null;
        [Mandatory]
        public Name[] Names { get; set; } = null;
    }

    /// <summary>
    /// Person names
    /// </summary>
    public class Names
    {
        [Mandatory]
        public Name[] Current { get; set; } // Or is it "Name"?
        [Optional]
        public Name[] BirthName { get; set; }
        [Optional]
        public Name[] MaidenName { get; set; }
        [Optional]
        public string MothersMaidenName { get; set; }
    }

    /// <summary>
    /// Should this be merged within the NameArticle class-type?
    /// </summary>
    public class Name
    {
        // Represents the NameArticle fields, may replace the NameArticle member:
        [Mandatory]
        public string Key { get; set; }

        [Mandatory]
        public string Value { get; set; }
        [Optional]
        public uint? Order { get; set; }
    }

    public class Document
    {
        [Mandatory]
        public string Type = "Bank";
        [Mandatory]
        public DocumentDetail[] Details = null;
    }

    public class DocumentDetail
    {
        [Mandatory]
        public string Key;
        [Mandatory]
        public string Value;
    }

    public class Address
    {
        private string addressLine2 = null;
        private string addressLine3 = null;
        private string addressLine4 = null;
        private string addressLine5 = null;
        private string addressLine6 = null;

        [Mandatory]
        public string Addressline1 { get; set; }

        [Optional]
        public string Addressline2
        {
            get
            {
                if (string.IsNullOrWhiteSpace(addressLine2)) return null; else return addressLine2;
            }
            set
            {
                addressLine2 = value;
            }
        }
        [Optional]
        public string Addressline3
        {
            get
            {
                if (string.IsNullOrWhiteSpace(addressLine3)) return null; else return addressLine3;
            }
            set
            {
                addressLine3 = value;
            }
        }
        [Optional]
        public string Addressline4
        {
            get
            {
                if (string.IsNullOrWhiteSpace(addressLine4)) return null; else return addressLine4;
            }
            set
            {
                addressLine4 = value;
            }
        }
        [Optional]
        public string Addressline5
        {
            get
            {
                if (string.IsNullOrWhiteSpace(addressLine5)) return null; else return addressLine5;
            }
            set
            {
                addressLine5 = value;
            } // i.e. NFUM "Town"
        }
        [Optional]
        public string Addressline6
        {
            get
            {
                if (string.IsNullOrWhiteSpace(addressLine6)) return null; else return addressLine6;
            }
            set
            {
                addressLine6 = value;
            } // i.e. NFUM "County"
        }

        [Mandatory]
        public string Postalcode { get; set; }

        [Mandatory]
        public string CountryCode { get; set; } = "GB";
    }

    public class Product
    {
        private Service[] _services = null;
        private ProductOption[] _productOptions = null;
        public string Name { get; set; } = LexisNexisHubRequest.IDU_PRODUCT_NAME;
        /// <summary>
        /// Product services - optional, return as null when there are no services at all to prevent it from being serialised in the request
        /// </summary>
        public Service[] Services
        {
            get
            {
                if (_services?.Length == 0) return null; else return _services;
            }
            set
            {
                _services = value;
            }
        }
        /// Product services - optional, return as null when there are no services at all to prevent it from being serialised in the request
        /// </summary>
        public ProductOption[] Options
        {
            get
            {
                if (_productOptions?.Length == 0) return null; else return _productOptions;
            }
            set
            {
                _productOptions = value;
            }
        }
    }

    /// <summary>
    /// Product-service
    /// </summary>
    public class Service
    {
        public string Name { get; set; } = LexisNexisHubRequest.DEFAULT_IDU_SERVICE_NAME;
    }

    /// <summary>
    /// Product-option
    /// </summary>
    public class ProductOption
    {
        public string Key { get; set; }
        public string Value { get; set; }
    }
}
