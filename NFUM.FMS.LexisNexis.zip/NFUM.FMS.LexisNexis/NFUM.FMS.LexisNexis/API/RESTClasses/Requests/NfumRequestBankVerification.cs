﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Globalization;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using NFUM.FMS.LexisNexis.Service.Interfaces;

namespace NFUM.FMS.LexisNexis.Service.API.RESTClasses
{
    /// <summary>
    /// Request-class for bank-account Verfications passed in through NFUM
    /// </summary>
    public class NfumRequestBankVerification : NfumRequest
    {
        // Sortcode validation values
        public const string HUB_SORTCODE_NOMATCH = "N";
        public const string HUB_SORTCODE_VALID = "V";
        public const string HUB_SORTCODE_INVALID_I = "I";
        public const string HUB_SORTCODE_INVALID_5 = "5";
        //
        public const string NFUM_SORTCODE_NOMATCH = "NOMATCH";
        public const string NFUM_SORTCODE_VALID = "VALID";
        public const string NFUM_SORTCODE_INVALID = "INVALID";

        // Account number validation values
        public const string HUB_ACCOUNT_NOMATCH = "N";
        public const string HUB_ACCOUNT_VALID = "V";
        public const string HUB_ACCOUNT_INVALID = "I";
        public const string HUB_ACCOUNT_I_6 = "6";
        public const string HUB_ACCOUNT_I_7 = "7";
        //
        public const string NFUM_ACCOUNT_NOMATCH = "NOMATCH";
        public const string NFUM_ACCOUNT_VALID = "VALID";
        public const string NFUM_ACCOUNT_INVALID = "INVALID";
        public const string NFUM_ACCOUNT_I_6 = "SIXOFEIGHT";
        public const string NFUM_ACCOUNT_I_7 = "SEVENOFEIGHT";

        // Account-name validation values
        public const string HUB_ACCOUNTNAME_NOMATCH = "N";
        public const string HUB_ACCOUNTNAME_VALID = "V";
        //
        public const string NFUM_ACCOUNTNAME_NOMATCH = "NOMATCH";
        public const string NFUM_ACCOUNTNAME_VALID = "VALID";

        // Account address validation values
        public const string HUB_ACCOUNTADDRESS_NOMATCH = "N";
        public const string HUB_ACCOUNTADDRESS_CURRENT = "C";
        public const string HUB_ACCOUNTADDRESS_PREVIOUS = "P";
        public const string HUB_ACCOUNTADDRESS_FORWARDING = "F";
        //
        public const string NFUM_ACCOUNTADDRESS_NOMATCH = "NOMATCH";
        public const string NFUM_ACCOUNTADDRESS_CURRENT = "CURRENT";
        public const string NFUM_ACCOUNTADDRESS_PREVIOUS = "PREVIOUS";
        public const string NFUM_ACCOUNTADDRESS_FORWARDING = "FORWARDING";

        // Account status validation values
        public const string HUB_ACCOUNTSTATUS_NOMATCH = "N";
        public const string HUB_ACCOUNTSTATUS_LIVE = "L";
        public const string HUB_ACCOUNTSTATUS_CLOSED = "C";
        //
        public const string NFUM_ACCOUNTSTATUS_NOMATCH = "NOMATCH";
        public const string NFUM_ACCOUNTSTATUS_LIVE = "LIVE";
        public const string NFUM_ACCOUNTSTATUS_CLOSED = "CLOSED";


        public override string ProductName { get { return LexisNexisHubRequest.IDU_PRODUCT_NAME; } }
        public override string ProductCategory { get { return LexisNexisHubRequest.IDU_BANKVERIFICATION_CATEGORY; } }

        /// <summary>
        /// Constructor - pass in the minimum set of mandatory fields - multiple references
        /// </summary>
        /// <param name="references"></param>
        /// <param name="surName"></param>
        /// <param name="dateOfBirth"></param>
        /// <param name="address1"></param>
        /// <param name="sortcode"></param>
        /// <param name="accountNumber"></param>
        public NfumRequestBankVerification(string[] references, string surName, string dateOfBirth, string address1, string sortcode, string accountNumber)
        {
            References = references;
            Surname = surName;
            DateOfBirth = dateOfBirth;
            Address1 = address1;
            SortCode = sortcode;
            AccountNumber = accountNumber;
        }

        /// <summary>
        /// Constructor - pass in the minimum set of mandatory fields - using a single reference
        /// </summary>
        /// <param name="reference"></param>
        /// <param name="surName"></param>
        /// <param name="dateOfBirth"></param>
        /// <param name="address1"></param>
        /// <param name="sortcode"></param>
        /// <param name="accountNumber"></param>
        public NfumRequestBankVerification(string reference, string surName, string dateOfBirth, string address1, string sortcode, string accountNumber)
        {
            References = new string[] { reference };
            Surname = surName;
            DateOfBirth = dateOfBirth;
            Address1 = address1;
            SortCode = sortcode;
            AccountNumber = accountNumber;
        }

        /// <summary>
        /// Make sure all minimum requirements have been meet
        /// </summary>
        /// <returns></returns>
        public override StringBuilder Validate()
        {
            const int SORTCODE_LENGTH = 6;
            StringBuilder errors = new StringBuilder();
            try
            {
                //if (string.IsNullOrEmpty(Postcode)) errors.AppendLine("No postcode supplied"); // To-Do: Does LN require this even though NFUM-spec marks it as optional?
                if (References == null || References?.Length == 0 || string.IsNullOrEmpty(References?[0])) errors.AppendLine("No reference(s) supplied");
                if (string.IsNullOrEmpty(Address1)) errors.AppendLine("No address-line 1 supplied");
                if (string.IsNullOrEmpty(Surname)) errors.AppendLine("No surname supplied");
                if (string.IsNullOrEmpty(SortCode)) errors.AppendLine("No sort-code supplied");
                else if (SortCode.Length != SORTCODE_LENGTH) errors.AppendLine($"Sort-code length is {SortCode.Length}, expected {SORTCODE_LENGTH}");
                if (string.IsNullOrEmpty(AccountNumber)) errors.AppendLine("No account-number supplied");
                if (string.IsNullOrEmpty(DateOfBirth)) errors.AppendLine("No date-of-birth supplied");
                else
                {
                    // Validate date-format YYYY-MM-DD
                    try { DateTime dateOfBirth = DateTime.ParseExact(DateOfBirth, "yyyy-MM-dd", CultureInfo.InvariantCulture); } catch { errors.AppendLine($"{DateOfBirth} is not in the format yyyy-MM-DD"); }
                }
            }
            catch (Exception ex)
            {
                errors.AppendLine($"Validation error: {ex.ToString()}");
            }
            return errors;
        }

        /// <summary>
        /// Parse the Identify Verification response
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="references">LN references</param>
        /// <param name="nfumResponses">List of responses to be populated</param>
        /// <param name="jObject">JSON response object</param>
        /// <returns>A list of error-messages if something had gone wrong</returns>
        public override List<string> ParseResponse(List<string> references, Newtonsoft.Json.Linq.JObject jObject, ref object nfumResponses)
        {
            List<string> errorList = new List<string>();
            // Get references:
            IEnumerable<JToken> tokenReferences = jObject.SelectTokens("references");
            foreach (JToken items in tokenReferences)
            {
                foreach (var item in items)
                {
                    references.Add(item.ToString());
                }
            }
            // Get results from all the systems:
            IEnumerable<JToken> outputResults = jObject.SelectTokens("outputresults");
            List<NfumResponseBankVerification> nfumResponsesBankVerification = new List<NfumResponseBankVerification>();

            foreach (JToken items in outputResults)
            {
                foreach (var item in items)
                {
                    NfumResponseBankVerification nfumResponseBankVerification = new NfumResponseBankVerification(references.ToArray());
                    // Create NFUM response for each system
                    string responseThisSystem = (string)item.SelectToken("system");
                    nfumResponseBankVerification.System = responseThisSystem;
                    nfumResponseBankVerification.ResultID = (string)item.SelectToken("systemresponse.summary.id");
                    nfumResponseBankVerification.IdentityResult = (string)item.SelectToken("systemresponse.summary.resulttext");                    
                    nfumResponseBankVerification.IDKey = (string)item.SelectToken("systemresponse.summary.ikey");
                    nfumResponseBankVerification.SortCode = (string)item.SelectToken("systemresponse.bankaccountverification.sortcode");
                    nfumResponseBankVerification.AccountNumber = (string)item.SelectToken("systemresponse.bankaccountverification.accountnumber");
                    nfumResponseBankVerification.AccountName = (string)item.SelectToken("systemresponse.bankaccountverification.accountname");
                    nfumResponseBankVerification.AccountStatus = (string)item.SelectToken("systemresponse.bankaccountverification.accountstatus");
                    nfumResponseBankVerification.AccountAddress = (string)item.SelectToken("systemresponse.bankaccountverification.accountaddress");
                    string errorCode = (string)item.SelectToken("systemresponse.bankaccountverification.errorcode");

                    var errors = (string)item.SelectToken("systemresponse.summary.errors.error.details");
                    // Were any errors returned from the API?
                    if (!string.IsNullOrEmpty(errors))
                    {
                        nfumResponseBankVerification.Error = errors;
                        errorList.Add(errors);
                    }
                    if (!string.IsNullOrWhiteSpace(errorCode)) errorList.Add($"Error code: {errorCode}");

                    // Apply transformations:
                    // -1: Transform Sort-code:
                    switch (nfumResponseBankVerification.SortCode)
                    {
                        case HUB_SORTCODE_NOMATCH:
                            nfumResponseBankVerification.SortCode = NFUM_SORTCODE_NOMATCH;
                            break;
                        case HUB_SORTCODE_VALID:
                            nfumResponseBankVerification.SortCode = NFUM_SORTCODE_VALID;
                            break;
                        case HUB_SORTCODE_INVALID_I:
                        case HUB_SORTCODE_INVALID_5:
                            nfumResponseBankVerification.SortCode = NFUM_SORTCODE_INVALID;
                            break;
                        default: // Invalid?
                            nfumResponseBankVerification.SortCode = NFUM_SORTCODE_INVALID;
                            break;
                    }
                    // -2: Transform Account-number:
                    switch (nfumResponseBankVerification.AccountNumber)
                    {
                        case HUB_ACCOUNT_NOMATCH:
                            nfumResponseBankVerification.AccountNumber = NFUM_ACCOUNT_NOMATCH;
                            break;
                        case HUB_ACCOUNT_VALID:
                            nfumResponseBankVerification.AccountNumber = NFUM_ACCOUNT_VALID;
                            break;
                        case HUB_ACCOUNT_INVALID:
                            nfumResponseBankVerification.AccountNumber = NFUM_ACCOUNT_INVALID;
                            break;
                        case HUB_ACCOUNT_I_6:
                            nfumResponseBankVerification.AccountNumber = NFUM_ACCOUNT_I_6;
                            break;
                        case HUB_ACCOUNT_I_7:
                            nfumResponseBankVerification.AccountNumber = NFUM_ACCOUNT_I_7;
                            break;
                        default: // Invalid?
                            nfumResponseBankVerification.AccountNumber = NFUM_ACCOUNT_INVALID;
                            break;
                    }
                    // -3: Transform Account-name:
                    switch (nfumResponseBankVerification.AccountName)
                    {
                        case HUB_ACCOUNTNAME_NOMATCH:
                            nfumResponseBankVerification.AccountName = NFUM_ACCOUNTNAME_NOMATCH;
                            break;
                        case HUB_ACCOUNTNAME_VALID:
                            nfumResponseBankVerification.AccountName = NFUM_ACCOUNTNAME_VALID;
                            break;
                        default: // N-match?
                            nfumResponseBankVerification.AccountName = NFUM_ACCOUNTNAME_NOMATCH;
                            break;
                    }
                    // -4: Transform Account-address:
                    switch (nfumResponseBankVerification.AccountAddress)
                    {
                        case HUB_ACCOUNTADDRESS_NOMATCH:
                            nfumResponseBankVerification.AccountAddress = NFUM_ACCOUNTADDRESS_NOMATCH;
                            break;
                        case NFUM_ACCOUNTADDRESS_CURRENT:
                            nfumResponseBankVerification.AccountAddress = NFUM_ACCOUNTADDRESS_CURRENT;
                            break;
                        case HUB_ACCOUNTADDRESS_PREVIOUS:
                            nfumResponseBankVerification.AccountAddress = NFUM_ACCOUNTADDRESS_PREVIOUS;
                            break;
                        case HUB_ACCOUNTADDRESS_FORWARDING:
                            nfumResponseBankVerification.AccountAddress = NFUM_ACCOUNTADDRESS_FORWARDING;
                            break;
                        default: // No-match?
                            nfumResponseBankVerification.AccountAddress = NFUM_ACCOUNTADDRESS_NOMATCH;
                            break;
                    }
                    // -5: Transform Account-status:
                    switch (nfumResponseBankVerification.AccountStatus)
                    {
                        case HUB_ACCOUNTSTATUS_NOMATCH:
                            nfumResponseBankVerification.AccountStatus = NFUM_ACCOUNTSTATUS_NOMATCH;
                            break;
                        case NFUM_ACCOUNTSTATUS_LIVE:
                            nfumResponseBankVerification.AccountStatus = NFUM_ACCOUNTSTATUS_LIVE;
                            break;
                        case HUB_ACCOUNTSTATUS_CLOSED:
                            nfumResponseBankVerification.AccountStatus = NFUM_ACCOUNTSTATUS_CLOSED;
                            break;
                        default: // No-match?
                            nfumResponseBankVerification.AccountStatus = NFUM_ACCOUNTSTATUS_NOMATCH;
                            break;
                    }
                    nfumResponsesBankVerification.Add(nfumResponseBankVerification);
                }
            }
            nfumResponses = nfumResponsesBankVerification;
            return errorList;
        }
    }
}
