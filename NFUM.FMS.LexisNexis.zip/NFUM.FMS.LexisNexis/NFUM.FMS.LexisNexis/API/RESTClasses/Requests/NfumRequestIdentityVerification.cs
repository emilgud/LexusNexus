﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Globalization;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using NFUM.FMS.LexisNexis.Service.Interfaces;

namespace NFUM.FMS.LexisNexis.Service.API.RESTClasses
{
    /// <summary>
    /// Request-class for Identity Verficationas passed in through NFUM
    /// </summary>
    public class NfumRequestIdentityVerification : NfumRequest
    {
        public const string HUB_RESULT_PASS = "PASS";
        public const string HUB_RESULT_REFER = "REFER";
        public const string HUB_RESULT_FAIL = "FAIL";
        public const string NFUM_RESULT_PASS = "PASS";
        public const string NFUM_RESULT_REFER = "CHECK";
        public const string NFUM_RESULT_FAIL = "FAIL";

        public override string ProductName { get { return LexisNexisHubRequest.IDU_PRODUCT_NAME; } }
        public override string ProductCategory { get { return LexisNexisHubRequest.IDU_IDENTITY_CATEGORY; } }

        /// <summary>
        /// Constructor - pass in the minimum set of mandatory fields - multiple references
        /// </summary>
        /// <param name="references"></param>
        /// <param name="surName"></param>
        /// <param name="dateOfBirth"></param>
        /// <param name="address1"></param>
        /// <param name="postcode"></param>
        public NfumRequestIdentityVerification(string[] references, string surName, string dateOfBirth, string address1, string postcode)
        {
            References = references;
            Surname = surName;
            DateOfBirth = dateOfBirth;
            Address1 = address1;
            Postcode = postcode;
        }

        /// <summary>
        /// Constructor - pass in the minimum set of mandatory fields - using a single reference
        /// </summary>
        /// <param name="reference"></param>
        /// <param name="surName"></param>
        /// <param name="dateOfBirth"></param>
        /// <param name="address1"></param>
        /// <param name="postcode"></param>
        public NfumRequestIdentityVerification(string reference, string surName, string dateOfBirth, string address1, string postcode)
        {
            References = new string[] { reference };
            Surname = surName;
            DateOfBirth = dateOfBirth;
            Address1 = address1;
            Postcode = postcode;
        }

        /// <summary>
        /// Make sure all minimum requirements have been meet
        /// </summary>
        /// <returns></returns>
        public override StringBuilder Validate()
        {
            StringBuilder errors = new StringBuilder();
            try
            {
                if (References == null || References?.Length == 0 || string.IsNullOrEmpty(References?[0])) errors.AppendLine("No reference(s) supplied");
                if (string.IsNullOrEmpty(Address1)) errors.AppendLine("No address-line 1 supplied");
                if (string.IsNullOrEmpty(Surname)) errors.AppendLine("No surname supplied");
                if (string.IsNullOrEmpty(DateOfBirth)) errors.AppendLine("No date-of-birth supplied");
                else
                {
                    // Validate date-format YYYY-MM-DD
                    try { DateTime dateOfBirth = DateTime.ParseExact(DateOfBirth, "yyyy-MM-dd", CultureInfo.InvariantCulture); } catch { errors.AppendLine($"{DateOfBirth} is not in the format yyyy-MM-DD"); }
                }
            }
            catch (Exception ex)
            {
                errors.AppendLine($"Validation error: {ex.ToString()}");
            }
            // Note - this being mandatory is not in NFUM requirement but Lexis Nexis requires it:
            if (string.IsNullOrEmpty(Postcode)) errors.AppendLine("No postcode supplied");
            return errors;
        }

        /// <summary>
        /// Parse the Identify Verification response
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="references">LN references</param>
        /// <param name="nfumResponses">List of responses to be populated</param>
        /// <param name="jObject">JSON response object</param>
        /// <returns>A list of error-messages if something had gone wrong</returns>
        public override List<string> ParseResponse( List<string> references, Newtonsoft.Json.Linq.JObject jObject, ref object nfumResponses)
        {
            List<string> errorList = new List<string>();
            // Get references:
            IEnumerable<JToken> tokenReferences = jObject.SelectTokens("references");
            foreach (JToken items in tokenReferences)
            {
                foreach (var item in items)
                {
                    references.Add(item.ToString());
                }
            }
            // Get results from all the systems:
            IEnumerable<JToken> outputResults = jObject.SelectTokens("outputresults");
            List <NfumResponseIdentityVerification> nfumResponsesIdentityVerification = new List<NfumResponseIdentityVerification>();

            foreach (JToken items in outputResults)
            {

                foreach (var item in items)
                {
                    NfumResponseIdentityVerification nfumResponseIdentityVerification = new NfumResponseIdentityVerification(references.ToArray());
                    // Create NFUM response for each system
                    string responseThisSystem = (string)item.SelectToken("system");
                    nfumResponseIdentityVerification.System = responseThisSystem;
                    nfumResponseIdentityVerification.ResultID = (string)item.SelectToken("systemresponse.summary.id");
                    nfumResponseIdentityVerification.IdentityResult = (string)item.SelectToken("systemresponse.summary.resulttext");
                    nfumResponseIdentityVerification.IDKey = (string)item.SelectToken("systemresponse.summary.ikey");
                    var errors = (string)item.SelectToken("systemresponse.summary.errors.error.details");
                    // Were any errors returned from the API?
                    if (!string.IsNullOrEmpty(errors))
                    {
                        nfumResponseIdentityVerification.Error = errors;
                        errorList.Add(errors);
                    }

                    // Apply transformations:
                    // -: Transform LN results "PASS", "FAIL", "REFER" into: "PASS", "FAIL", "CHECK":
                    if (nfumResponseIdentityVerification.IdentityResult == HUB_RESULT_PASS) nfumResponseIdentityVerification.IdentityResult = NFUM_RESULT_PASS;
                    else if (nfumResponseIdentityVerification.IdentityResult == HUB_RESULT_REFER) nfumResponseIdentityVerification.IdentityResult = NFUM_RESULT_REFER;
                    else if (nfumResponseIdentityVerification.IdentityResult == HUB_RESULT_FAIL) nfumResponseIdentityVerification.IdentityResult = NFUM_RESULT_FAIL;

                    nfumResponsesIdentityVerification.Add(nfumResponseIdentityVerification);
                }
            }
            nfumResponses = nfumResponsesIdentityVerification;
            return errorList;
        }
    }
}
