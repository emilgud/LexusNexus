﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Globalization;
using NFUM.FMS.LexisNexis.Service.Interfaces;
using Newtonsoft.Json.Linq;

namespace NFUM.FMS.LexisNexis.Service.API.RESTClasses
{
    /// <summary>
    /// Base-class for all types of requests
    /// </summary>
    public abstract class NfumRequest : INfumRequest
    {
        protected Product _product = null;
        protected Product[] _products = null;
        protected ProductOption[] _productOptions = null;
        protected string _forename = null;
        protected string _middlename = null;

        public abstract string ProductName{ get; }
        public abstract string ProductCategory { get; }

        /// <summary>
        /// Single product
        /// </summary>
        [Newtonsoft.Json.JsonIgnore]
        public Product Product
        {
            get { if (_product == null && (_products != null && _products?.Length > 0)) return _products[0]; else return _product; }
            set
            {
                // When setting a single product, assume that this is the only product to include
                _product = value;
                Products = new Product[] { _product };
            }
        }

        /// <summary>
        /// Products
        /// </summary>
        [Newtonsoft.Json.JsonIgnore]
        public Product[] Products
        {
            get
            {
                if ((_products == null || _products?.Length == 0) && _product != null)
                {
                    _products = new Product[] { _product };
                }
                return _products;
            }
            set
            {
                _products = value;
            }
        }

        /// <summary>
        /// Product-options
        /// </summary>
        [Newtonsoft.Json.JsonIgnore]
        public ProductOption[] ProductOptions
        {
            get
            {
                return _productOptions;
            }
            set
            {
                _productOptions = value;
            }
        }

        /// <summary>
        /// Mandatory  : consumer defined identifier stored against the search for future retrieval from IDU if required
        /// </summary>
        [Newtonsoft.Json.JsonIgnore]
        public virtual string[] References { get; set; }

        /// <summary>
        /// Reference in the NFUM interface is defined as one value while LN has an array of references. For now, just return the first memeber of this array
        /// </summary>
        public virtual string Reference
        {
            get
            {
                if (References == null || References?.Length == 0) return string.Empty;
                else return References[0];
            }
        }

        /// <summary>
        /// Optional : result-id (i.e. "ID" in LN) from previous request
        /// </summary>
        public string ResultID { get; set; } = null;

        /// <summary>
        /// Optional : ID-key (i.e. "Ikey" in LN) from previous request
        /// </summary>
        public string IDKey { get; set; } = null; 
        public string Gender  { get; set; } = null;
        public string BusinessName { get; set; } = null; 
        public string Surname { get; set; } = null; 
        public string Forename
        {
            get
            {
                if (string.IsNullOrWhiteSpace(_forename)) return null; else return _forename;
            }
            set
            {
                _forename = value;
            }
        }

        public string Middlename
        {
            get
            {
                if (string.IsNullOrWhiteSpace(_middlename)) return null; else return _middlename;
            }
            set
            {
                _middlename = value;
            }
        }
        public string DateOfBirth { get; set; }
        public string Address1 { get; set; } 
        public string Address2 { get; set; } = null;
        public string Address3 { get; set; } = null;
        public string Address4 { get; set; } = null;
        public string Town { get; set; } = null;
        public string County { get; set; } = null;
        public string Postcode { get; set; } // 	
        public string SortCode { get; set; } = null; 
        public string AccountNumber { get; set; } = null; 
        public string PassportMRZ { get; set; } = null; 

        /// <summary>
        /// Make sure all minimum requirements have been meet
        /// </summary>
        /// <returns></returns>
        public abstract StringBuilder Validate();

        /// <summary>
        /// Map the NFUM request to a valid Lexis Nexis hub request object ()
        /// </summary>
        /// <returns></returns>
        public virtual LexisNexisHubRequest ToLexisNexisHubRequest()
        {
            if (Product == null)
            {
                // default to IDU-address service
                Service[] services = { new Service { Name = LexisNexisHubRequest.DEFAULT_IDU_SERVICE_NAME } };
                Product =
                    new Product
                    {
                        Name = ProductName,
                        Services = services
                    };
            }
            string[] references = this.References;

            // Names for Personal details - based on specs, NFUM clients will provide one "current" forename/surname only:
            Names names = new Names();
            List<Name> currentNames = new List<Name>();
            if (!string.IsNullOrWhiteSpace(this.Forename)) currentNames.Add(new Name { Key = LexisNexisHubRequest.NAME_KEY_TYPE_FORENAME, Value = this.Forename });
            if (!string.IsNullOrWhiteSpace(this.Middlename)) currentNames.Add(new Name { Key = LexisNexisHubRequest.NAME_KEY_TYPE_MIDDLENAME, Value = this.Middlename });
            if (!string.IsNullOrWhiteSpace(this.Surname)) currentNames.Add(new Name { Key = LexisNexisHubRequest.NAME_KEY_TYPE_SURNAME, Value = this.Surname });
            names.Current = currentNames.ToArray();

            // Names for Company details - based on specs, NFUM clients will provide up tp one business-name only:
            CompanyDetails companyDetails;
            if (string.IsNullOrWhiteSpace(this.BusinessName))
                companyDetails = null;
            else
            {
                companyDetails = new CompanyDetails();
                List<Name> companyNames = new List<Name>();
                companyNames.Add(new Name { Key = LexisNexisHubRequest.NAME_KEY_TYPE_BUSINESSNAME, Value = this.BusinessName });
                companyDetails.Names = companyNames.ToArray();
                companyDetails.RegistrationNumber = null; // currently not used for lookups
            }

            // Personal details for Subject:
            PersonalDetails personalDetails = new PersonalDetails();
            personalDetails.DOB = this.DateOfBirth; 
            personalDetails.Names = names;
            personalDetails.Gender = this.Gender;

            // Addresses for Subject - based on specs, NFUM clients will provide one only:
            Address[] addresses = { new Address {
                Addressline1 = this.Address1,
                Addressline2 = this.Address2,
                Addressline3 = this.Address3,
                Addressline4 = this.Address4,
                Addressline5 = string.IsNullOrWhiteSpace(this.Town) ? this.County : this.Town, // If there is no mapping to value of 'town' then supply the details passed in 'county'
                Addressline6 = string.IsNullOrWhiteSpace(this.Town) ? string.Empty : this.County,
                Postalcode = this.Postcode }
            };

            // Documents:
            Document[] documents = null;
            // -1: Bank account document:
            if (!string.IsNullOrWhiteSpace(this.AccountNumber)) {
                documents = new Document[] { new Document
                    {
                        Type = "Bank",
                        Details = new DocumentDetail[] { 
                            new DocumentDetail { Key = "AccountNumber", Value = this.AccountNumber},
                            new DocumentDetail { Key = "SortCode", Value = this.SortCode }
                        }
                    }
                };
            }
            // -2: Passport document:
            if (!string.IsNullOrWhiteSpace(this.PassportMRZ))
            {
                Document[] documentsPassport = new Document[] { new Document
                    {
                        Type = "Passport",
                        Details = new DocumentDetail[] {
                            new DocumentDetail { Key = "PassportMRZ", Value = this.PassportMRZ}
                        }
                    }
                };
                // Either set this as the subject's documents, or merge it with previous one(s) using Linq:
                if (documents == null)
                    documents = documentsPassport;
                else
                    documents = documents.Concat(documentsPassport).ToArray();
            }

            // Finally - the Subject to verify:
            Subject subject = new Subject();

            if (string.IsNullOrWhiteSpace(this.BusinessName))
                subject.Type = LexisNexisHubRequest.SUBJECT_TYPE_DEFAULT;
            else
                subject.Type = LexisNexisHubRequest.SUBJECT_TYPE_BUSINESS;

            subject.PersonalDetail = personalDetails;
            subject.CompanyDetail = companyDetails;
            subject.Addresses = addresses;
            subject.Documents = documents;
            // Retrieve any configure product-options that need sending across:
            GetProductOptions(this.Products);

            // Product with Services:
            return new LexisNexisHubRequest { References = references, Subject = subject, Products = this.Products };
        }

        /// <summary>
        /// Get the options belonging to all products
        /// </summary>
        /// <param name="products"></param>
        protected void GetProductOptions(Product[] products)
        {
            foreach (Product product in this.Products)
            {
                List<ProductOption> productOptions = new List<ProductOption>();
                // Add any product-option that may have been passed in:
                if (this?.ProductOptions != null) productOptions.AddRange(this.ProductOptions);

                // Add previously returned Id-key and Result-Id as product-options, if provided:
                if (!string.IsNullOrWhiteSpace(this.ResultID) && !string.IsNullOrWhiteSpace(this.IDKey))
                {
                    // The following logic assumes that any provided result-ID (i.e. "ID") and ID-Key (i.e. IKey) apply to all products:
                    productOptions.AddRange(new ProductOption[]
                        {
                            new ProductOption { Key = "ID", Value = this.ResultID },
                            new ProductOption { Key = "IKey", Value = this.IDKey }
                        }
                    );
                }
                if (productOptions.Count > 0) product.Options = productOptions.ToArray();
            }
        }
        /// <summary>
        /// Parse the response for a given response in a given NFUM response-type
        /// </summary>
        /// <param name="references"></param>
        /// <param name="jObject"></param>
        /// <returns>A list of error-messages if something had gone wrong</returns>
        public abstract List<string> ParseResponse(List<string> references, Newtonsoft.Json.Linq.JObject jObject, ref object nfumResponses);
    }
}

