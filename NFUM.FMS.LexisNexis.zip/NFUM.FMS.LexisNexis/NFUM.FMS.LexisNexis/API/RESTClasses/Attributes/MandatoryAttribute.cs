﻿using System;

namespace NFUM.FMS.LexisNexis.Service.API.RESTClasses
{   
    // To do
    internal class MandatoryAttribute : Attribute
    {
    }
}