﻿using IO.Swagger;
using IO.Swagger.Models;
using NFUM.FMS.LexisNexis.Service.API.RESTClasses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NFUM.FMS.LexisNexis.Server.Swagger.Controllers.Utilities
{
    /// <summary>
    /// Shared utilities for controllers
    /// </summary>
    public static class ApiConfigUtilities
    {
        /// <summary>
        /// Construct an array of Products with services from the Config. 
        /// Only include enabled items. 
        /// </summary>
        /// <param name="configSettings"></param>
        /// <param name="productGroup">Optional filter to only select products for the given group</param>
        /// <param name="serviceGroup">Optional filter to only select services for the given group</param>
        /// <returns></returns>
        public static Product[] GetProductsFromConfig(ConfigSettings configSettings, string productGroup = "", string serviceGroup = "", string productName = "")
        {
            List<Product> productList = new List<Product>();
            foreach (var productItem in configSettings.LexisNexisProducts)
            {
                if (productItem.Enabled == "1" && (string.IsNullOrWhiteSpace(productGroup) || productGroup == productItem.Group) && (!string.IsNullOrWhiteSpace(productGroup) || (string.IsNullOrWhiteSpace(productGroup) && productName == productItem.Name)))
                {
                    List<Service.API.RESTClasses.Service> serviceList = new List<Service.API.RESTClasses.Service>();
                    if (productItem?.LexisNexisServices != null)
                    {
                        foreach (var serviceItem in productItem?.LexisNexisServices)
                        {
                            if (serviceItem.Enabled == "1" && (string.IsNullOrWhiteSpace(serviceGroup) || serviceGroup == serviceItem.Group))
                            {
                                serviceList.Add(new Service.API.RESTClasses.Service { Name = serviceItem.Name });
                            }
                        }
                    }
                    productList.Add(new Product { Name = productItem.Name, Services = serviceList.ToArray() });
                }
            }
            return productList.ToArray();
        }

        /// <summary>
        /// Construct an array of enabled Product-options for a given product listed in the Config.
        /// </summary>
        /// <param name="configSettings"></param>
        /// <param name="productName">Product for what the options are being queried</param>
        /// <returns></returns>
        public static ProductOption[] GetProductOptionsFromConfig(ConfigSettings configSettings, string productName)
        {
            List<ProductOption> productOptionList = new List<ProductOption>();
            foreach (var productItem in configSettings.LexisNexisProducts)
            {
                // Find the product (enabled or not):
                if (productName == productItem.Name)
                {
                    if (productItem?.Options != null)
                    {
                        foreach (var optionItem in productItem?.Options)
                        {
                            if (optionItem.Enabled == "1")
                            {
                                productOptionList.Add(new ProductOption { Key = optionItem.Key, Value = optionItem.Value });
                            }
                        }
                    }
                }
            }
            return productOptionList.ToArray();
        }
    }

}