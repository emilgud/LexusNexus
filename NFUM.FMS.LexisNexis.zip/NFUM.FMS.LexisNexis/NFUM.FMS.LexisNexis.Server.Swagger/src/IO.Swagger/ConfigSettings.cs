﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace IO.Swagger
{
    /// <summary>
    /// Structure for API Configuration
    /// </summary>
    public class ConfigSettings
    {
        /// <summary>
        /// URL base for calling into the Lexis Nexus service 
        /// This is either LN's own direct url or the URL to the service hosted in NFUM's APIM
        /// </summary>
        public string LexisNexisEndpointBase { get; set; }

        /// <summary>
        /// URL base for calling into the Lexis Nexus 
        /// </summary>
        public string NfumApiUrlBase { get; set; }

        /// <summary>
        /// Keyvault URL
        /// </summary>
        public string KeyVault { get; set; }

        /// <summary>
        /// Flag for including custom-headers
        /// Set to 1 for calling into the APIM-hosted Lexis Nexis service, otherwise can be set to 0
        /// </summary>
        public string UseCustomerHeaders { get; set; } = "1";

        /// <summary>
        /// Lexis Nexis Products
        /// </summary>
        public LexisNexisProduct[] LexisNexisProducts { get; set; }
 
        /// <summary>
        /// 
        /// Lexis Nexis product
        /// </summary>
        public class LexisNexisProduct
        {
            private LexisNexisService[] _lexisNexisServices = null;
            private ProductOption[] _productOptions = null;

            /// <summary>
            /// Product name
            /// </summary>
            public string Name { get; set; }
            
            /// <summary>
            /// Flag whether a product is to be included in the search: "1" = include, "0" = exclude
            /// </summary>
            public string Enabled { get; set; } = "1";
            
            /// <summary>
            /// Optional grouping, allowing filtering of groups of products to be included: "" = no grouping, anything else is considered a group
            /// </summary>
            public string Group { get; set; } = string.Empty;

            /// <summary>
            /// Services
            /// </summary>
            public LexisNexisService[] LexisNexisServices
            {
                get
                {
                    if (_lexisNexisServices?.Length == 0) return null; else return _lexisNexisServices;
                }
                set
                {
                    _lexisNexisServices = value;
                }
            }

            /// <summary>
            /// Product-Options
            /// </summary>           
            public ProductOption[] Options
            {
                get
                {
                    if (_productOptions?.Length == 0) return null; else return _productOptions;
                }
                set
                {
                    _productOptions = value;
                }
            }
        }
        
        /// <summary>
        /// Lexis Nexis Product-Service
        /// </summary>
        public class LexisNexisService
        {
            /// <summary>
            /// Service name
            /// </summary>
            public string Name { get; set; }

            /// <summary>
            /// Flag whether a service is to be included in the search: "1" = include, "0" = exclude
            /// </summary>
            public string Enabled { get; set; } = "1";

            /// <summary>
            /// Optional grouping, allowing filtering of groups of services to be included: "" = no grouping, anything else is considered a group
            /// </summary>
            public string Group { get; set; } = string.Empty;
        }

        /// <summary>
        /// Lexis Nexis Product-Option
        /// </summary>
        public class ProductOption
        {
            /// <summary>
            /// Option Key
            /// </summary>
            public string Key { get; set; }

            /// <summary>
            /// Option-value
            /// </summary>
            public string Value { get; set; }

            /// <summary>
            /// Flag whether an option is to be included in the search: "1" = include, "0" = exclude
            /// </summary>
            public string Enabled { get; set; } = "1";
        }

    }
}
