/*
 * Parties API
 *
 * Customised additions to VerificationRequestItem
 * *
 */

using System;
using System.Linq;
using System.IO;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using Newtonsoft.Json;
using NFUM.FMS.LexisNexis.Service.API.RESTClasses;

namespace IO.Swagger.Models
{ 
    public partial class VerificationRequestItem : IEquatable<VerificationRequestItem>
    { 
        /// <summary>
        /// A (temporory?) method to map a VerificationRequestItem-object (based on NFUM Swagger) with an NfumRequestIdentityVerification-object (based on SD-document)
        /// </summary>
        /// <returns></returns>
        public NfumRequestIdentityVerification ToNfumRequestIdentityVerification()
        {
            try
            {
                var nfumRequestIdentityVerification = new NfumRequestIdentityVerification(reference: this.Reference, surName: this.Surname, dateOfBirth: ((DateTime)this.DateOfBirth).ToString("yyyy-MM-dd"), address1: this.Address1, postcode: this.Postcode);
                if (!string.IsNullOrWhiteSpace(this.Address2)) nfumRequestIdentityVerification.Address2 = this.Address2; else nfumRequestIdentityVerification.Address2 = null;
                if (!string.IsNullOrWhiteSpace(this.Address3)) nfumRequestIdentityVerification.Address3 = this.Address3; else nfumRequestIdentityVerification.Address3 = null;
                if (!string.IsNullOrWhiteSpace(this.Address4)) nfumRequestIdentityVerification.Address4 = this.Address4; else nfumRequestIdentityVerification.Address4 = null;
                if (!string.IsNullOrWhiteSpace(this.Address5)) nfumRequestIdentityVerification.Town = this.Address5; else nfumRequestIdentityVerification.Town = null;
                 if (!string.IsNullOrWhiteSpace(this.Forename)) nfumRequestIdentityVerification.Forename = this.Forename; else nfumRequestIdentityVerification.Forename = null;
                 if (!string.IsNullOrWhiteSpace(this.Middlename)) nfumRequestIdentityVerification.Middlename = this.Middlename; else nfumRequestIdentityVerification.Middlename = null;
               //if (!string.IsNullOrWhiteSpace(this.Address5)) nfumRequestIdentityVerification.County = this.Address5; // No explicit reference to count or postcode
                //if (!string.IsNullOrWhiteSpace(this.Middlename)) nfumRequestIdentityVerification.Middlename = this.Middlename;  // No middlename in current definition of nfumRequestIdentityVerification

                return nfumRequestIdentityVerification;
            }
            catch
            {
                return null;
            }
        }

    }
}
