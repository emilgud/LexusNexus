﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using NFUM.FMS.LexisNexis.Service.API.RESTClasses;

namespace NFUM.FMS.LexisNexis.Server.Swagger.Models.Customised
{
    interface ICommonRequestMethods
    {
        public NfumRequest ToNfumRequest<T>() where T : NfumRequest;
    }
}
