﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Microsoft.Azure.KeyVault;
using Microsoft.Azure.KeyVault.Models;
using Microsoft.Azure.Services.AppAuthentication;

namespace NFUM.Azure.KeyVault.ValueProvider
{
    public class KeyVaultMember
    {
        #region Locals
        private string _key;
        private string _keyVaultName;
        private string _errorMessage = "";
        private string _recoveryLevel = "(UNKNOWN)";
        private int _errors = 0;
        #endregion Locals

        #region Properties
        public string ErrorMessage => _errorMessage;
        public int Errors => _errors;
        public bool IsSuccessFul => _errors < 1;
        public string RecoveryLevel  => _recoveryLevel;

        #endregion Properties

        #region Constructors
        public KeyVaultMember(string key, string keyVaultName)
        { 
            _key = key;
            _keyVaultName = keyVaultName;
        }
        #endregion

        #region Methods
        /// <summary>
        /// Get keyvault value for given vault and key
        /// </summary>
        /// <returns></returns>
        public async Task<string> GetValue(int maxRetries = 0)
        {
            string value = null;
            StringBuilder messages = new StringBuilder();

            int retries = 0;

            while (retries <= maxRetries)
            {
                try
                {
                    AzureServiceTokenProvider azureServiceTokenProvider = new AzureServiceTokenProvider();
                    KeyVaultClient keyVaultClient = new KeyVaultClient(new KeyVaultClient.AuthenticationCallback(azureServiceTokenProvider.KeyVaultTokenCallback));
                    var secret = await keyVaultClient.GetSecretAsync($"{_keyVaultName}secrets/{_key}")
                            .ConfigureAwait(false);
                    value = secret?.Value;
                    _recoveryLevel = secret?.Attributes.RecoveryLevel;
                    //bool? isManaged = secret?.Managed;

                    // Reset errors if we eventually found a value:
                    _errors = (value == null) ? _errors : 0;

                    break; // all seems well - no need for retries
                }
                /// <exception cref="KeyVaultErrorException">
                /// Thrown when the operation returned an invalid status code
                /// For throttling errors see https://docs.microsoft.com/azure/key-vault/tutorial-net-create-vault-azure-web-app
                /// </exception>
                catch (KeyVaultErrorException keyVaultException)
                {
                    messages.AppendLine(keyVaultException.Message);
                    _errors++;
                    retries++;
                    // Wait for your next retry:
                    System.Threading.Thread.Sleep(GetWaitTime(maxRetries));
                }
                catch (Exception ex)
                {
                    // Do not retry other execptions
                    _errors++;
                    messages.AppendLine(ex.ToString());
                    break;
                }
            }
            _errorMessage = messages.ToString();
            return value;
        }

        /// <summary>
        /// This method implements exponential backoff if there are 429 errors from Azure Key Vault
        /// </summary>
        /// <param name="retryCount"></param>
        /// <returns></returns>
        private static int GetWaitTime(int retryCount)
        {
            int waitTime = ((int)Math.Pow(2, retryCount) * 100);
            return waitTime;
        }

        /// <summary>
        /// This method fetches a token from Azure Active Directory, which can then be provided to Azure Key Vault to authenticate
        /// NOT USED - uing Managed Identity instead
        /// </summary>
        /// <returns></returns>
        public async Task<string> GetAccessTokenAsync()
        {
            var azureServiceTokenProvider = new AzureServiceTokenProvider();
            string accessToken = await azureServiceTokenProvider.GetAccessTokenAsync("https://vault.azure.net");
            return accessToken;
        }
        #endregion
    }
}
