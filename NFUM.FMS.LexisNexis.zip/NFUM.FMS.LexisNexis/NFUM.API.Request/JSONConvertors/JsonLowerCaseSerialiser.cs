﻿using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using System;
using System.Collections.Generic;
using System.Text;
/// <summary>
/// A handy serialiser returning objects as indented JSON with lowercase member-names and ignoring any members that have value null
/// </summary>
namespace NFUM.API.Request.JsonConvertors
{
    public class JsonLowerCaseSerialiser 
    {
        private JsonSerializerSettings jsonSerializerSettings;
        public JsonLowerCaseSerialiser() {
            jsonSerializerSettings = new JsonSerializerSettings
                    {
                        NullValueHandling = NullValueHandling.Ignore,
                        ContractResolver = new LowercaseContractResolver()
                    };
        }
        /// <summary>
        /// Return object as an indented JSON with lowercase member-names and ignoring any members that have value null
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public string SerialiseObject(object value)
        {
            return JsonConvert.SerializeObject(value, Formatting.Indented, jsonSerializerSettings);
        }
    }
    /// <summary>
    /// Allow NewtonSoft JSON serialiser to always return lowercase members
    /// </summary>
    internal class LowercaseContractResolver : DefaultContractResolver
    {
        protected override string ResolvePropertyName(string propertyName)
        {
            return propertyName.ToLower();
        }
    }

}
