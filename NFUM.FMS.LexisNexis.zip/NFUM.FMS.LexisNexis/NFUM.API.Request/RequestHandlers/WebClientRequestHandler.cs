﻿using NFUM.API.Constants;
using System;
using System.Net;
using System.IO;
using System.Text;
using System.Collections.Generic;

namespace NFUM.API.RequestHandlers
{
    public class WebClientRequestHandler: IRequestHandler
    {
        private string _errorMessage = "";
        private int _errors = 0;
        public string ErrorMessage => _errorMessage;
        public int Errors => _errors;
        public bool IsSuccessFul => _errors < RequestConstants.RequestMaxRetries;
        public Dictionary<string, string> CustomRequestHeaders { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        public int? StatusCode { get => _statusCode; }
        public string ReasonPhrase { get => _reasonPhrase; }

        private Dictionary<string, string> customRequestHeaders = new Dictionary<string, string>();
        private int? _statusCode = null;
        private string _reasonPhrase = string.Empty;
        public string PostData(string url, byte[] data)
        {
            throw new NotImplementedException();
        }
        public string PostData(string url, string json, string bearerToken = null)
        {
            throw new NotImplementedException();
        }
        public string GetData(string url)
        {
            // NOTE - Post hasn't been implemented yet!
            _errorMessage = "";
           using (var client = new WebClient())
            {
                client.Headers.Add(RequestConstants.UserAgent, RequestConstants.UserAgentValue);
                var response = "";
                StringBuilder messages = new StringBuilder();

                for (int i = 1; i <= RequestConstants.RequestMaxRetries; i++)
                {
                    try {
                        response = client.DownloadString(url);
                        break;
                    }
                    catch (WebException e)
                    {
                        _errors ++;
                        string errorMessage = "";
                        if (e.Status == WebExceptionStatus.ProtocolError)
                        {
                            WebResponse resp = e.Response;
                            using (StreamReader sr = new StreamReader(resp.GetResponseStream()))
                            {
                                errorMessage = sr.ReadToEnd();
                            }
                        }
                        else errorMessage = e.ToString();
                        messages.AppendLine(errorMessage);
                    }
                    catch (Exception ex)
                    {
                        _errors ++;
                        messages.AppendLine(ex.ToString());
                    }
                }
                _errorMessage = messages.ToString();
                return response;
            }
        }
    }
}
