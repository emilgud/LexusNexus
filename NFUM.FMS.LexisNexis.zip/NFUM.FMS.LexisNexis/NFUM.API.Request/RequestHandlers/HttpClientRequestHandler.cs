﻿using NFUM.API.Constants;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;

namespace NFUM.API.RequestHandlers
{
    public class HttpClientRequestHandler: IRequestHandler
    {
        public string ErrorMessage => _errorMessage;
        public int Errors => _errors;
        public bool IsSuccessFul => _errors < RequestConstants.RequestMaxRetries;
        public Dictionary<string, string> CustomRequestHeaders { get => customRequestHeaders; set => customRequestHeaders = value; }
        public int? StatusCode { get => _statusCode;  }
        public string ReasonPhrase { get => _reasonPhrase; }

        private string _errorMessage = string.Empty;
        private int _errors = 0;
        private Dictionary<string, string> customRequestHeaders = new Dictionary<string, string>();
        private int? _statusCode = null;
        private string _reasonPhrase = string.Empty;


        /// <summary>
        /// Not yet implemented
        /// </summary>
        /// <param name="url"></param>
        /// <param name="data"></param>
        /// <returns></returns>
        public string PostData(string url, byte[] data)
        {
            var content = string.Empty;
            // TO DO

            return content;
        }

        /// <summary>
        /// Post JSON document
        /// </summary>
        /// <param name="url"></param>
        /// <param name="json"></param>
        /// <returns></returns>
        public string PostData(string url, string json, string bearerToken = null)
        {
            string content = string.Empty;
            _errorMessage = "";
            StringBuilder messages = new StringBuilder();

            for (int i = 1; i <= RequestConstants.RequestMaxRetries; i++)
            {
                try
                {
                    using (System.Net.Http.HttpClient client = new System.Net.Http.HttpClient())
                    {

                        client.BaseAddress = new System.Uri(url);                       
                        client.DefaultRequestHeaders.Clear();
                        client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));

                        if (!string.IsNullOrEmpty(bearerToken)) client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", bearerToken);

                        // Add any custom request-header if defined:
                        if (customRequestHeaders != null)
                        {
                            foreach (var customRequestHeader in customRequestHeaders)
                            {
                                client.DefaultRequestHeaders.Add(customRequestHeader.Key, customRequestHeader.Value);
                            }
                        }

                        HttpContent httpContent = new StringContent(json, UTF8Encoding.UTF8, "application/json");
                        HttpResponseMessage message = client.PostAsync(url, httpContent).Result;
                        try { content = message.Content.ReadAsStringAsync().Result; } catch { content = string.Empty; }
                        _statusCode = (int?)message?.StatusCode;
                        _reasonPhrase = message?.ReasonPhrase;
                        if (message.IsSuccessStatusCode)
                        {
                            break;
                        }
                        else 
                        { 
                            if (!string.IsNullOrWhiteSpace(content)) messages.AppendLine(content); 
                            messages.AppendLine(message.ToString()); 
                            _errors++; }
                        }
                }
                catch (Exception ex)
                {
                    _errors++;
                    messages.AppendLine(ex.ToString());
                }
            }
            _errorMessage = messages.ToString();
            return content;
        }

        public string GetData(string url)
        {
            using (var httpClient = new HttpClient())
            {
                var response = "";
                _errorMessage = "";
                StringBuilder messages = new StringBuilder();

                for (int i = 1; i <= RequestConstants.RequestMaxRetries; i++)
                {
                    try
                    {
                        httpClient.Timeout = new TimeSpan(0, RequestConstants.DefaultTimeout, 0);
                        httpClient.DefaultRequestHeaders.Add(RequestConstants.UserAgent, RequestConstants.UserAgentValue);
                        string responseString = httpClient.GetStringAsync(new Uri(url)).Result;
                        break;
                    }
                    catch (Exception ex)
                    {
                        _errors++;
                        messages.AppendLine(ex.ToString());
                    }
                }
                _errorMessage = messages.ToString();
                return response;
            }
        }
    }
}
