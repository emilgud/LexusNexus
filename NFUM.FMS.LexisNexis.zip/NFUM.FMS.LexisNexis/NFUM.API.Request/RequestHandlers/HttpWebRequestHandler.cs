﻿using NFUM.API.Constants;
using System;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Collections.Generic;

namespace NFUM.API.RequestHandlers
{
    public class HttpWebRequestHandler : IRequestHandler
    {
        private string _errorMessage = "";
        private int _errors = 0;
        public string ErrorMessage => _errorMessage;
        public int Errors => _errors;
        public bool IsSuccessFul => _errors < RequestConstants.RequestMaxRetries;
        public Dictionary<string, string> CustomRequestHeaders { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        public int? StatusCode { get => _statusCode; }
        public string ReasonPhrase { get => _reasonPhrase; }

        private Dictionary<string, string> customRequestHeaders = new Dictionary<string, string>();
        private int? _statusCode = null;
        private string _reasonPhrase = string.Empty;
        /// <summary>
        /// Post JSON document - not yet implemented
        /// </summary>
        /// <param name="url"></param>
        /// <param name="json"></param>
        /// <returns></returns>
        public string PostData(string url, string json, string bearerToken = null)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Post byte-data
        /// </summary>
        /// <param name="url"></param>
        /// <param name="data"></param>
        /// <returns></returns>
        public string PostData(string url, byte[] data)
        {
            _errorMessage = "";

            var content = string.Empty;
            StringBuilder messages = new StringBuilder();

            for (int i = 1; i <= RequestConstants.RequestMaxRetries; i++)
            {
                try
                {
                    var request = (HttpWebRequest)WebRequest.Create(url);
                    request.Timeout = 1000 * 60 * RequestConstants.DefaultTimeout;
                    request.Method = "POST";
                    request.ContentType = "application/x-www-form-urlencoded";
                    request.ContentLength = data.Length;
                    using (var stream = request.GetRequestStream())
                    {
                        stream.Write(data, 0, data.Length);
                        var response = (HttpWebResponse)request.GetResponse();
                        content = new StreamReader(response.GetResponseStream()).ReadToEnd();
                        request = null;
                        break;
                    }
                }
                catch (Exception ex)
                {
                    _errors++;
                    messages.AppendLine(ex.ToString());
                }
            }
            _errorMessage = messages.ToString();
            return content;
        }
        public string GetData(string url)
        {
            _errorMessage = "";
            var request = (HttpWebRequest)WebRequest.Create(url);
            request.Timeout = 1000 * 60 * RequestConstants.DefaultTimeout;
            request.Method = "GET";
            request.UserAgent = RequestConstants.UserAgentValue;
            request.AutomaticDecompression = DecompressionMethods.Deflate | DecompressionMethods.GZip;

            var content = string.Empty;
            StringBuilder messages = new StringBuilder();

            for (int i = 1; i <= RequestConstants.RequestMaxRetries; i++)
            {
                try
                {
                    using (var response = (HttpWebResponse)request.GetResponse())
                    {
                        using (var stream = response.GetResponseStream())
                        {
                            using (var sr = new StreamReader(stream))
                            {
                                content = sr.ReadToEnd();
                                break;
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    _errors++;
                    messages.AppendLine(ex.ToString());
                }
            }
            request = null;
            _errorMessage = messages.ToString();
            return content;
        }

    }
}
