﻿using System.Collections.Generic;

namespace NFUM.API.RequestHandlers
{
    public interface IRequestHandler
    {
        string GetData(string url);
        string PostData(string url, string json, string bearerToken = null);
        string PostData(string url, byte[] data);
        Dictionary<string, string> CustomRequestHeaders { get; set; }
        string ErrorMessage { get; }
        int Errors { get; }
        bool IsSuccessFul { get; }
        int? StatusCode { get; }
        string ReasonPhrase { get; }
    }
}
