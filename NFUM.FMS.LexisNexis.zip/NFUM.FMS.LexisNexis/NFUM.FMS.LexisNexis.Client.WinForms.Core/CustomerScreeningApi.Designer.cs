﻿namespace NFUM.FMS.LexisNexis.Client.WinForms.Core
{
    partial class CustomerScreeningApi
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label10 = new System.Windows.Forms.Label();
            this.Reference = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label13 = new System.Windows.Forms.Label();
            this.IDKey = new System.Windows.Forms.TextBox();
            this.ServicesList = new System.Windows.Forms.CheckedListBox();
            this.btnVerify = new System.Windows.Forms.Button();
            this.ResultID = new System.Windows.Forms.TextBox();
            this.Postcode = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.County = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.Town = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.Address4 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.Address3 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.Address2 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.Address1 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.DOB = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.Surname = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.Forename = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.LoginDetails = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.IdentityVerificationResults = new System.Windows.Forms.TextBox();
            this.btnExit = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.Messages = new System.Windows.Forms.RichTextBox();
            this.Middlename = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(6, 25);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(67, 15);
            this.label10.TabIndex = 21;
            this.label10.Text = "Reference *";
            // 
            // Reference
            // 
            this.Reference.Location = new System.Drawing.Point(107, 22);
            this.Reference.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Reference.Name = "Reference";
            this.Reference.Size = new System.Drawing.Size(164, 23);
            this.Reference.TabIndex = 20;
            this.Reference.Text = "Hub_Test132";
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.Middlename);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.IDKey);
            this.groupBox1.Controls.Add(this.ServicesList);
            this.groupBox1.Controls.Add(this.btnVerify);
            this.groupBox1.Controls.Add(this.ResultID);
            this.groupBox1.Controls.Add(this.Postcode);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.County);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.Town);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.Address4);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.Address3);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.Address2);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.Address1);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.DOB);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.Surname);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.Forename);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.Reference);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Location = new System.Drawing.Point(15, 15);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox1.Size = new System.Drawing.Size(904, 209);
            this.groupBox1.TabIndex = 22;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "NFUM identity request";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(453, 175);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(12, 15);
            this.label13.TabIndex = 46;
            this.label13.Text = "/";
            // 
            // IDKey
            // 
            this.IDKey.Location = new System.Drawing.Point(466, 172);
            this.IDKey.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.IDKey.Name = "IDKey";
            this.IDKey.Size = new System.Drawing.Size(73, 23);
            this.IDKey.TabIndex = 44;
            // 
            // ServicesList
            // 
            this.ServicesList.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ServicesList.FormattingEnabled = true;
            this.ServicesList.Location = new System.Drawing.Point(566, 22);
            this.ServicesList.Name = "ServicesList";
            this.ServicesList.Size = new System.Drawing.Size(330, 148);
            this.ServicesList.TabIndex = 45;
            // 
            // btnVerify
            // 
            this.btnVerify.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnVerify.Location = new System.Drawing.Point(810, 175);
            this.btnVerify.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnVerify.Name = "btnVerify";
            this.btnVerify.Size = new System.Drawing.Size(88, 27);
            this.btnVerify.TabIndex = 44;
            this.btnVerify.Text = "&Verify!";
            this.btnVerify.UseVisualStyleBackColor = true;
            this.btnVerify.Click += new System.EventHandler(this.btnVerify_Click);
            // 
            // ResultID
            // 
            this.ResultID.Location = new System.Drawing.Point(375, 172);
            this.ResultID.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.ResultID.Name = "ResultID";
            this.ResultID.Size = new System.Drawing.Size(76, 23);
            this.ResultID.TabIndex = 43;
            // 
            // Postcode
            // 
            this.Postcode.Location = new System.Drawing.Point(375, 142);
            this.Postcode.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Postcode.Name = "Postcode";
            this.Postcode.Size = new System.Drawing.Size(164, 23);
            this.Postcode.TabIndex = 42;
            this.Postcode.Text = "BS7 8EU";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(280, 175);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(90, 15);
            this.label6.TabIndex = 43;
            this.label6.Text = "Result ID/ID key";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(280, 145);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(64, 15);
            this.label12.TabIndex = 43;
            this.label12.Text = "Postcode *";
            // 
            // County
            // 
            this.County.Location = new System.Drawing.Point(375, 112);
            this.County.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.County.Name = "County";
            this.County.Size = new System.Drawing.Size(164, 23);
            this.County.TabIndex = 40;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(280, 115);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(46, 15);
            this.label11.TabIndex = 41;
            this.label11.Text = "County";
            // 
            // Town
            // 
            this.Town.Location = new System.Drawing.Point(375, 82);
            this.Town.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Town.Name = "Town";
            this.Town.Size = new System.Drawing.Size(164, 23);
            this.Town.TabIndex = 38;
            this.Town.Text = "BRISTOL";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(280, 85);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(35, 15);
            this.label9.TabIndex = 39;
            this.label9.Text = "Town";
            // 
            // Address4
            // 
            this.Address4.Location = new System.Drawing.Point(375, 52);
            this.Address4.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Address4.Name = "Address4";
            this.Address4.Size = new System.Drawing.Size(164, 23);
            this.Address4.TabIndex = 36;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(280, 55);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(58, 15);
            this.label8.TabIndex = 37;
            this.label8.Text = "Address 4";
            // 
            // Address3
            // 
            this.Address3.Location = new System.Drawing.Point(375, 22);
            this.Address3.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Address3.Name = "Address3";
            this.Address3.Size = new System.Drawing.Size(164, 23);
            this.Address3.TabIndex = 34;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(280, 25);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(58, 15);
            this.label7.TabIndex = 35;
            this.label7.Text = "Address 3";
            // 
            // Address2
            // 
            this.Address2.Location = new System.Drawing.Point(107, 172);
            this.Address2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Address2.Name = "Address2";
            this.Address2.Size = new System.Drawing.Size(164, 23);
            this.Address2.TabIndex = 30;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 175);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(58, 15);
            this.label5.TabIndex = 31;
            this.label5.Text = "Address 2";
            // 
            // Address1
            // 
            this.Address1.Location = new System.Drawing.Point(107, 142);
            this.Address1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Address1.Name = "Address1";
            this.Address1.Size = new System.Drawing.Size(164, 23);
            this.Address1.TabIndex = 28;
            this.Address1.Text = "200";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 145);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(59, 15);
            this.label4.TabIndex = 29;
            this.label4.Text = "Adress 1 *";
            // 
            // DOB
            // 
            this.DOB.Location = new System.Drawing.Point(107, 112);
            this.DOB.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.DOB.Name = "DOB";
            this.DOB.Size = new System.Drawing.Size(164, 23);
            this.DOB.TabIndex = 26;
            this.DOB.Text = "1976-04-11";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 115);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(81, 15);
            this.label3.TabIndex = 27;
            this.label3.Text = "Date of Birth *";
            // 
            // Surname
            // 
            this.Surname.Location = new System.Drawing.Point(107, 82);
            this.Surname.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Surname.Name = "Surname";
            this.Surname.Size = new System.Drawing.Size(164, 23);
            this.Surname.TabIndex = 24;
            this.Surname.Text = "STONE";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 85);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(62, 15);
            this.label2.TabIndex = 25;
            this.label2.Text = "Surname *";
            // 
            // Forename
            // 
            this.Forename.Location = new System.Drawing.Point(107, 52);
            this.Forename.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Forename.Name = "Forename";
            this.Forename.Size = new System.Drawing.Size(76, 23);
            this.Forename.TabIndex = 22;
            this.Forename.Text = "ROY";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 55);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(102, 15);
            this.label1.TabIndex = 23;
            this.label1.Text = "Fore/Middlename";
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.Controls.Add(this.LoginDetails);
            this.groupBox2.Location = new System.Drawing.Point(14, 347);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox2.Size = new System.Drawing.Size(905, 108);
            this.groupBox2.TabIndex = 23;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Login and Request details";
            // 
            // LoginDetails
            // 
            this.LoginDetails.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.LoginDetails.Font = new System.Drawing.Font("Courier New", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.LoginDetails.Location = new System.Drawing.Point(7, 22);
            this.LoginDetails.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.LoginDetails.Multiline = true;
            this.LoginDetails.Name = "LoginDetails";
            this.LoginDetails.ReadOnly = true;
            this.LoginDetails.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.LoginDetails.Size = new System.Drawing.Size(891, 78);
            this.LoginDetails.TabIndex = 0;
            // 
            // groupBox3
            // 
            this.groupBox3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox3.Controls.Add(this.IdentityVerificationResults);
            this.groupBox3.Location = new System.Drawing.Point(15, 461);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox3.Size = new System.Drawing.Size(905, 132);
            this.groupBox3.TabIndex = 24;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Identity-verification  results";
            // 
            // IdentityVerificationResults
            // 
            this.IdentityVerificationResults.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.IdentityVerificationResults.Font = new System.Drawing.Font("Courier New", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.IdentityVerificationResults.Location = new System.Drawing.Point(7, 15);
            this.IdentityVerificationResults.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.IdentityVerificationResults.Multiline = true;
            this.IdentityVerificationResults.Name = "IdentityVerificationResults";
            this.IdentityVerificationResults.ReadOnly = true;
            this.IdentityVerificationResults.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.IdentityVerificationResults.Size = new System.Drawing.Size(891, 103);
            this.IdentityVerificationResults.TabIndex = 1;
            // 
            // btnExit
            // 
            this.btnExit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnExit.Location = new System.Drawing.Point(827, 600);
            this.btnExit.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(93, 25);
            this.btnExit.TabIndex = 25;
            this.btnExit.Text = "&Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox4.Controls.Add(this.Messages);
            this.groupBox4.Location = new System.Drawing.Point(15, 231);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox4.Size = new System.Drawing.Size(904, 110);
            this.groupBox4.TabIndex = 26;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Messages and Errors";
            // 
            // Messages
            // 
            this.Messages.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Messages.Font = new System.Drawing.Font("Courier New", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Messages.Location = new System.Drawing.Point(9, 22);
            this.Messages.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Messages.Name = "Messages";
            this.Messages.ReadOnly = true;
            this.Messages.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedVertical;
            this.Messages.Size = new System.Drawing.Size(887, 80);
            this.Messages.TabIndex = 0;
            this.Messages.Text = "";
            // 
            // Middlename
            // 
            this.Middlename.Location = new System.Drawing.Point(198, 52);
            this.Middlename.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Middlename.Name = "Middlename";
            this.Middlename.Size = new System.Drawing.Size(73, 23);
            this.Middlename.TabIndex = 23;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(185, 55);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(12, 15);
            this.label14.TabIndex = 46;
            this.label14.Text = "/";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(933, 631);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "Form1";
            this.Text = "Lexis Nexis IDU through Hub";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox Reference;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox Postcode;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox County;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox Town;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox Address4;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox Address3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox Address2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox Address1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox DOB;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox Surname;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox Forename;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnVerify;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox LoginDetails;
        private System.Windows.Forms.TextBox IdentityVerificationResults;
        private System.Windows.Forms.Button btnExit;

        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.RichTextBox Messages;
        private System.Windows.Forms.CheckedListBox ServicesList;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox IDKey;
        private System.Windows.Forms.TextBox ResultID;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox Middlename;
    }
}

