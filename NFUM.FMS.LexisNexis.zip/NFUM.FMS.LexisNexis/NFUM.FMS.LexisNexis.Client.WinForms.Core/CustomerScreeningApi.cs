﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using NFUM.API.Request.JsonConvertors;
using NFUM.FMS.LexisNexis.Service.API.RESTClasses;
using NFUM.FMS.LexisNexis.Service.Interfaces;

namespace NFUM.FMS.LexisNexis.Client.WinForms.Core
{
    public partial class CustomerScreeningApi : Form
    {
        #region Locals
        private ApiRequest<NfumRequestIdentityVerification> _apiRequest;
        #endregion

        #region Initialise
        public CustomerScreeningApi()
        {
            InitializeComponent();

            Populateservices();
            _apiRequest = new ApiRequest<NfumRequestIdentityVerification>();
            // Register for message-cast:
            _apiRequest.RegisterForMessageCast(new ApiRequest<NfumRequestIdentityVerification>.CastMessageHandler(OnMessageCast));
            // Register for exception-cast event:
            _apiRequest.ThrownException += ApiRequest_ThrownException;
        }

         /// <summary>
        /// Add IDU services
        /// </summary>
        private void Populateservices() {
            this.ServicesList.Items.Clear();
            // Default service:
            this.ServicesList.Items.Add(LexisNexisHubRequest.DEFAULT_IDU_SERVICE_NAME, true);
            // Optional other services:
            this.ServicesList.Items.AddRange(new string[] {
                //LexisNexisHubRequest.IDU_SERVICE_ADDRESS,
                LexisNexisHubRequest.IDU_SERVICE_SMARTLINK,
                LexisNexisHubRequest.IDU_SERVICE_CREDITACTIVE,
                LexisNexisHubRequest.IDU_SERVICE_DEATHSCREEN,
                LexisNexisHubRequest.IDU_SERVICE_DOB,
                LexisNexisHubRequest.IDU_SERVICE_SANCTION,
                LexisNexisHubRequest.IDU_SERVICE_CCJ,
                LexisNexisHubRequest.IDU_SERVICE_INSOLVENCY
            });
        }
        #endregion

        #region Form events
        private void btnVerify_Click(object sender, EventArgs e)
        {
            this.LoginDetails.Clear();
            this.IdentityVerificationResults.Clear();
            this.Messages.Clear();

            IdentityVerificationResults.Text = GetData();
        }
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        #endregion

        #region Methods
        /// <summary>
        /// Get- and process providers
        /// </summary>
        /// <returns></returns>
        string GetData()
        {
            if (_apiRequest.Login())
            {
                this.LoginDetails.Text = $"Login: {_apiRequest?.ApiLoginClient?.UserLogin}{Environment.NewLine}TransactionId: {_apiRequest?.ApiLoginClient?.LoginTransactionId}{Environment.NewLine}Bearer-token: { _apiRequest?.ApiLoginClient?.BearerToken}{Environment.NewLine}";

                // Create NFUM lookup structure with minimum set of criteria:
                NfumRequestIdentityVerification nfumRequestIdentityVerification = new NfumRequestIdentityVerification(
                    reference: this.Reference.Text,
                    surName: this.Surname.Text,
                    dateOfBirth: this.DOB.Text,
                    address1: this.Address1.Text,
                    postcode: this.Postcode.Text);

                //Provide some optional details if filled-in:
                if (!string.IsNullOrEmpty(this.Address2.Text)) nfumRequestIdentityVerification.Address2 = this.Address2.Text;
                if (!string.IsNullOrEmpty(this.Address3.Text)) nfumRequestIdentityVerification.Address3 = this.Address3.Text;
                if (!string.IsNullOrEmpty(this.Address4.Text)) nfumRequestIdentityVerification.Address4 = this.Address4.Text;
                if (!string.IsNullOrEmpty(this.Town.Text)) nfumRequestIdentityVerification.Town = this.Town.Text;
                if (!string.IsNullOrEmpty(this.County.Text)) nfumRequestIdentityVerification.County = this.County.Text;
                if (!string.IsNullOrEmpty(this.Forename.Text)) nfumRequestIdentityVerification.Forename = this.Forename.Text;
                if (!string.IsNullOrEmpty(this.Middlename.Text)) nfumRequestIdentityVerification.Middlename = this.Middlename.Text;
                if (!string.IsNullOrEmpty(this.ResultID.Text)) nfumRequestIdentityVerification.ResultID = this.ResultID.Text;
                if (!string.IsNullOrEmpty(this.IDKey.Text)) nfumRequestIdentityVerification.IDKey = this.IDKey.Text;

                // Get all the selected IDU services from the form:
                List<Service.API.RESTClasses.Service> serviceList = new List<Service.API.RESTClasses.Service>();
                foreach (var serviceItem in this.ServicesList.CheckedItems)
                {
                    serviceList.Add(new Service.API.RESTClasses.Service { Name = serviceItem.ToString() });
                }
                nfumRequestIdentityVerification.Product = new Product { Name = LexisNexisHubRequest.IDU_PRODUCT_NAME, Services = serviceList.ToArray() };

                // Post the request:
                string response = _apiRequest?.PostRequest(nfumRequestIdentityVerification);

                // Show the request-JSON:
                this.LoginDetails.Text += $"{Environment.NewLine}Request-JSON:{Environment.NewLine}{new JsonLowerCaseSerialiser().SerialiseObject(_apiRequest?.HubRequest)}{Environment.NewLine}";

                // Show the response-data:
                StringBuilder responses = new StringBuilder($"Raw response:{response}{Environment.NewLine}");

                // Formatted response:
                responses.AppendLine($"{Environment.NewLine}Formatted response:");

                int count = 1;
                foreach (string reference in _apiRequest?.References)
                {
                    responses.AppendLine($"--> Reference {count}: {reference}");
                    count++;
                }
                count = 1;
                foreach (NfumResponseIdentityVerification nfumResponseIdentityVerification in (List< NfumResponseIdentityVerification>)_apiRequest?.NfumResponses)
                {
                    responses.AppendLine($"--> Response {count}: ID-key {nfumResponseIdentityVerification.IDKey}, Result-ID {nfumResponseIdentityVerification.ResultID}, Identity-Result: {nfumResponseIdentityVerification.IdentityResult}");
                    if (!string.IsNullOrWhiteSpace(nfumResponseIdentityVerification.Error)) responses.AppendLine($"ERROR from API: {nfumResponseIdentityVerification.Error}");
                    count++;
                }
                count = 1;
                responses.AppendLine($"{Environment.NewLine}NFUM Json documents to return:");
                foreach (NfumResponseIdentityVerification nfumResponseIdentityVerification in (List<NfumResponseIdentityVerification>)_apiRequest?.NfumResponses)
                {
                    responses.AppendLine($"--> NFUM JSON {count}: {Environment.NewLine}{nfumResponseIdentityVerification.ToJson()}");
                    count++;
                }
                return responses.ToString();
            }
            else
            {
                ApiRequest_ThrownException(this, new ApiRequest<NfumRequestIdentityVerification>.ApiRequestArgs($"Could not log in: {_apiRequest.ErrorMessage}", "",null));
                return string.Empty;
            }
        }
        #endregion Methods

        #region Event handling
        /// <summary>
        /// New fragment of text has been cast
        /// </summary>
        /// <param name="message"></param>
        /// <returns></returns> 
        protected string OnMessageCast(string message)
        {
            this.Messages.AppendText(message, Color.Black);
            this.Messages.AppendText(Environment.NewLine);
            return message;
        }

        /// <summary>
        /// Exception in API refresh was raised
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void ApiRequest_ThrownException(object sender, ApiRequest<NfumRequestIdentityVerification>.ApiRequestArgs e) // <NfumRequestIdentityVerification>
        {
            this.Messages.AppendText($"ERROR: {e}", Color.Red);
            this.Messages.AppendText(Environment.NewLine);
        }
        #endregion Event handling
    }
    #region Extensions (local)
    /// <summary>
    /// Local type-extensions
    /// </summary>
    public static class RichTextBoxExtensions
    {
        /// <summary>
        ///  Extension to allow differently coloured sections in the rich-text box used for errors and messages
        /// </summary>
        /// <param name="box"></param>
        /// <param name="text"></param>
        /// <param name="color"></param>
        public static void AppendText(this RichTextBox box, string text, Color color)
        {
            box.SelectionStart = box.TextLength;
            box.SelectionLength = 0;
            box.SelectionColor = color;
            box.AppendText(text);
            box.SelectionColor = box.ForeColor;
        }
    }
    #endregion
}
