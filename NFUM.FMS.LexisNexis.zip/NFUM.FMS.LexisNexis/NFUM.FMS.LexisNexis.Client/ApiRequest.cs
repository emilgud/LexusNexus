﻿using System;
using System.Text;
using System.Diagnostics;
using System.Collections;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json.Serialization;
using NFUM.API;
using NFUM.API.RequestHandlers;
using NFUM.API.Request.JsonConvertors;
using NFUM.FMS.LexisNexis.Service;
using NFUM.FMS.LexisNexis.Service.API;
using NFUM.FMS.LexisNexis.Service.API.RESTClasses;
using NFUM.FMS.LexisNexis.Service.Interfaces;
using System.Collections.Generic;

/// <summary>
/// This code deals with processing Lexis Nexis API-requests for NFUM client applications
/// </summary>
namespace NFUM.FMS.LexisNexis.Client
{
    /// <summary>
    /// API request-processing for all types of NFUM request-types
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class ApiRequest<T> where T : NfumRequest
    {
        #region Properties
        public string ErrorMessage => _errorMessage;
        public int Errors => _errors;
        public bool IsSuccessFul => _errors < ApiConstants.REQUEST_MAX_RETRIES;
        public ApiLoginClient ApiLoginClient { get => apiLoginClient; }
        public ApiQueryClient ApiQueryClient { get => apiQueryClient; }
        public LexisNexisHubRequest HubRequest  { get => hubRequest; }
        public Dictionary<string, string> CustomRequestHeaders { get; set; }
        public Object NfumResponses { get => nfumResponses; }
        public List<string> References { get => references; }
        public int? StatusCode { get => _statusCode; }
        public string ReasonPhrase { get => _reasonPhrase; }
        #endregion Properties


        #region Delegates
        // Add delegate that casts information text-lines:
        public delegate string CastMessageHandler(string message);
        private CastMessageHandler _castMessage;
        public void RegisterForMessageCast(CastMessageHandler castMessageHandler) { _castMessage += castMessageHandler; }
        // Delegate to deal with exceptions:
        public class ApiRequestArgs : EventArgs
        {
            public readonly string ErrorMessage;
            public readonly string InformationalMessage;
            public readonly Exception Ex;
            // Constructor:
            public ApiRequestArgs(string errorMessage, string informationalMessage, Exception ex) { ErrorMessage = errorMessage; InformationalMessage = informationalMessage; Ex = ex; }
            // Read-friendly ToString():
            public override string ToString()
            {
                StringBuilder toStringMessage = new StringBuilder($"Error in API-Request: {ErrorMessage}{Environment.NewLine}");
                toStringMessage.AppendLine($"{ErrorMessage}{Environment.NewLine}Exception(s)");
                Exception exception = Ex;
                while (exception != null)
                {
                    toStringMessage.AppendLine($"{exception.Message}");
                    exception = exception.InnerException;
                }
                toStringMessage.AppendLine($"{Environment.NewLine}Additional information:");
                toStringMessage.AppendLine(InformationalMessage);
                return toStringMessage.ToString();
            }
        }
        public delegate void ExceptionHandler(object sender, ApiRequestArgs e);
        public event ExceptionHandler ThrownException;
        #endregion Delegates


        #region Locals
        protected string _errorMessage = "";
        protected int _errors = 0;
        static string _endPointUrlBase;
        static string _keyVault;
        static ApiLoginClient apiLoginClient = null;
        static ApiQueryClient apiQueryClient = null;
        private object nfumResponses = null; 
        private List<string> references = new List<string>();
        private LexisNexisHubRequest hubRequest = null;
        private int? _statusCode = null;
        private string _reasonPhrase = string.Empty;
        #endregion Locals

        #region Startup and initialisations
        public ApiRequest() : this(ApiConstants.LEXIS_NEXIS_API_ENDPOINT_DEFAULT) { }
        public ApiRequest(string endPointUrlBase) : this(endPointUrlBase, ApiConstants.KEY_VAULT_NAME) { }

        /// <summary>
        /// Constructor
        /// </summary>
        public ApiRequest(string endPointUrlBase, string keyVault)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(keyVault))_keyVault = ApiConstants.KEY_VAULT_NAME; else _keyVault = keyVault;
                _endPointUrlBase = endPointUrlBase;
                InitialiseConfiguration();
            }
            catch (Exception ex)
            {
                throw new Exception($"ApiRequest - InitialiseConfiguration() error: {ex.ToString()}", ex);
            }
        }
        /// <summary>
        /// Initialise the configuration 
        /// </summary>
        static void InitialiseConfiguration()
        {
            try
            {
                apiLoginClient = new ApiLoginClient(_endPointUrlBase, _keyVault);
                if (!apiLoginClient.IsSuccessFul) throw new Exception(apiLoginClient?.ErrorMessage);
                apiQueryClient = new ApiQueryClient(_endPointUrlBase);
            }
            catch (Exception ex)
            {
                throw new Exception("Exception InitialiseConfiguration(): " + ex.ToString());
            }
        }
        #endregion Startup and initialisations

        #region Methods
        /// <summary>
        /// Get session ID for given login
        /// </summary>
        /// <returns></returns>
        public bool Login()
        {
            var postData = new
            {
                user = apiLoginClient.UserLogin,
                password = apiLoginClient.Password
            };
            try
            {
                IRequestHandler requestHandler = new HttpClientRequestHandler();

                string response = requestHandler.PostData(apiLoginClient.EndPointUrl, JsonConvert.SerializeObject(postData));
                if (requestHandler.IsSuccessFul && (!string.IsNullOrWhiteSpace(response)))
                {
                    _castMessage?.Invoke($"Login response: {response}");
                    try
                    {
                        Newtonsoft.Json.Linq.JObject jObject = Newtonsoft.Json.Linq.JObject.Parse(response);

                        apiLoginClient.LoginTransactionId = (string)jObject.SelectToken("logintransactionid"); 
                        apiLoginClient.BearerToken = (string)jObject.SelectToken("bearertoken");
                    }
                    catch (Exception ex) {
                        _errorMessage = $"Exception when retrieving token and transaction ID from login-response '{apiLoginClient?.EndPointUrl}': {ex.ToString()}";
                        ThrownException?.Invoke(this, new ApiRequestArgs(_errorMessage, $"User-name: '{apiLoginClient?.UserLogin}'", null));
                        return false;
                    }
                    return true;
                }
                else
                {
                    _errorMessage = $"Error logging in on URL '{apiLoginClient?.EndPointUrl}': {requestHandler.ErrorMessage}";
                    ThrownException?.Invoke(this, new ApiRequestArgs(_errorMessage, $"User-name: '{apiLoginClient?.UserLogin}'", null));
                    return false;
                }
            }
            catch (Exception ex)
            {
                _errorMessage = $"Exception logging in on URL '{apiLoginClient?.EndPointUrl}': {ex.ToString()}";
                ThrownException?.Invoke(this, new ApiRequestArgs(_errorMessage, $"User-name: '{apiLoginClient?.UserLogin}'", null));
                return false;
            }
        }
 
        /// <summary>
        /// Perform an request against Lexis Nexis Hub
        /// </summary>
        /// <param name="nfumRequest">Look-up details provided by an NFUM client</param>
        /// <returns></returns>
        public string PostRequest(T nfumRequest)
        {
            _statusCode = null;
            _reasonPhrase = string.Empty;
            _errors = 0;
            _errorMessage = string.Empty;

            // First check the basics before attempting the call:
            if (apiLoginClient == null || string.IsNullOrEmpty(apiLoginClient?.BearerToken) || string.IsNullOrEmpty(apiLoginClient?.LoginTransactionId))
            {
                _errors ++;
                _errorMessage = "Not successfully logged in";
                ThrownException?.Invoke(this, new ApiRequestArgs(_errorMessage, "ApiRequest.LexisNexisHubRequest()", null));
                return string.Empty;
            }
            if (nfumRequest == null)
            {
                _errors ++;
                _errorMessage = "No identity requested to be verified";
                ThrownException?.Invoke(this, new ApiRequestArgs(_errorMessage, "ApiRequest.LexisNexisHubRequest()", null));
                return string.Empty;
            }
            // Validate the request for completeness of all mandatory fields:
            StringBuilder validationErrors = nfumRequest.Validate();
            if (validationErrors.Length > 0)
            {
                _errors ++;
                _errorMessage = $"identity request invalid: {validationErrors.ToString()}";
                ThrownException?.Invoke(this, new ApiRequestArgs(_errorMessage, "ApiRequest.LexisNexisHubRequest()", null));
                return string.Empty;
            }
            // Query-request:
            hubRequest = nfumRequest.ToLexisNexisHubRequest();
            Debug.WriteLine( new JsonLowerCaseSerialiser().SerialiseObject(hubRequest));
            try
            {
                // Perform the API request:
                IRequestHandler requestHandler = new HttpClientRequestHandler();

                // Pass in request-headers:
                requestHandler.CustomRequestHeaders = this.CustomRequestHeaders;

                // If the request-headers already contain the authorization for the NFUM AAD bearer-token for APIM then assume that the 
                // LN token returned from the LN login is already supplied through an aliased authorization header, to be subsitituted by APIM:
                string bearerToken = null;
                if (!CustomRequestHeaders.ContainsKey(Service.API.ApiConstants.AAD_BEARER_TOKEN)) bearerToken = apiLoginClient.BearerToken;
                
                string response = requestHandler.PostData(
                    apiQueryClient.EndPointUrl,
                    new JsonLowerCaseSerialiser().SerialiseObject(hubRequest), 
                    bearerToken);
                _statusCode = requestHandler.StatusCode;
                _reasonPhrase = requestHandler.ReasonPhrase;

                if (requestHandler.IsSuccessFul && (!string.IsNullOrWhiteSpace(response)))
                {
                    _castMessage?.Invoke($"Query response: {response}");
                    try
                    {
                        Newtonsoft.Json.Linq.JObject jObject = Newtonsoft.Json.Linq.JObject.Parse(response);
                        // Transform the response in an NFUM Response Identity Verification object:
                        if (jObject == null)
                        {
                            ThrownException?.Invoke(this, new ApiRequestArgs($"No query-response returned from'{apiQueryClient?.EndPointUrl}'", $"User-name: '{apiLoginClient?.UserLogin}'", null));
                            return string.Empty;
                        }
                        else
                        {
                            // Parse and map the response:
                            try
                            {
                                references.Clear();
                                List<string> errorList = nfumRequest.ParseResponse(references, jObject, ref nfumResponses);

                                if (errorList?.Count > 0) {
                                    _errors += errorList.Count;
                                    this._errorMessage += string.Join(", ", errorList.ToArray());
                                    ThrownException?.Invoke(this, new ApiRequestArgs($"Errors returned in the query-response from '{apiQueryClient?.EndPointUrl}': {string.Join(", ", errorList.ToArray())}", $"User-name: '{apiLoginClient?.UserLogin}'", null));
                                }
                            }
                            catch (Exception ex)
                            {
                                ThrownException?.Invoke(this, new ApiRequestArgs($"Exception when parsing members from the query-response '{apiQueryClient?.EndPointUrl}': {ex.ToString()}", $"User-name: '{apiLoginClient?.UserLogin}'", null));
                                _errorMessage += requestHandler?.ErrorMessage;
                                return string.Empty;
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        ThrownException?.Invoke(this, new ApiRequestArgs($"Exception when retrieving query-response '{apiQueryClient?.EndPointUrl}': {ex.ToString()}", $"User-name: '{apiLoginClient?.UserLogin}'", null));
                        _errorMessage += requestHandler?.ErrorMessage;
                        return string.Empty;
                    }
                    return response;
                }
                else
                {
                    ThrownException?.Invoke(this, new ApiRequestArgs($"Error querying URL '{apiQueryClient?.EndPointUrl}': {requestHandler.ErrorMessage}", $"User-name: '{apiLoginClient?.UserLogin}'", null));
                    _errorMessage += requestHandler?.ErrorMessage;
                    return _errorMessage;
                }
            }
            catch (Exception ex)
            {
                ThrownException?.Invoke(this, new ApiRequestArgs($"Exception querying URL '{apiQueryClient?.EndPointUrl}': {ex.ToString()}", $"User-name: '{apiLoginClient?.UserLogin}'", null));
                return string.Empty;
            }
        }
        #endregion
    }
}
